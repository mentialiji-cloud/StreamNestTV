# StreamNest TV

An original Android TV IPTV-player shell for user-supplied, legally authorized content.

## Version 0.1

- Android TV / Google TV launcher support
- Landscape TV interface
- D-pad focus and navigation
- Home cards for Live TV, Movies, Series, Favorites, and Settings
- Original StreamNest TV branding

This version intentionally contains no channels, credentials, or copyrighted media.

## Build

Open the folder in Android Studio, let Gradle sync, then build the `debug` variant. The APK is generated under `app/build/outputs/apk/debug/`.

## Next milestone

Add the provider screen, encrypted credential storage, Xtream-compatible API models, category/channel browsing, and Media3 playback.
