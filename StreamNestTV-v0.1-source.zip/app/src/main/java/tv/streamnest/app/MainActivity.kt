package tv.streamnest.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.tv.material3.*

private val Purple = Color(0xFF7C5CFF)
private val Ink = Color(0xFF090A10)
private val Panel = Color(0xFF171824)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { StreamNestApp() }
    }
}

private data class Destination(val title: String, val subtitle: String, val icon: ImageVector)

@Composable
private fun StreamNestApp() {
    var selected by remember { mutableStateOf("Home") }
    val destinations = listOf(
        Destination("Live TV", "Browse your channels", Icons.Default.LiveTv),
        Destination("Movies", "Your movie library", Icons.Default.Movie),
        Destination("Series", "Seasons and episodes", Icons.Default.Tv),
        Destination("Favorites", "Everything you saved", Icons.Default.Favorite),
        Destination("Settings", "Providers and playback", Icons.Default.Settings)
    )

    MaterialTheme {
        Box(
            Modifier.fillMaxSize().background(
                Brush.linearGradient(listOf(Color(0xFF17102F), Ink, Ink))
            )
        ) {
            Column(Modifier.fillMaxSize().padding(horizontal = 56.dp, vertical = 34.dp)) {
                Header()
                Spacer(Modifier.height(58.dp))
                when (selected) {
                    "Home" -> Home(destinations) { selected = it }
                    else -> Placeholder(selected) { selected = "Home" }
                }
            }
        }
    }
}

@Composable
private fun Header() {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Icon(Icons.Default.PlayCircle, null, tint = Purple, modifier = Modifier.size(42.dp))
        Spacer(Modifier.width(12.dp))
        Text("StreamNest", fontSize = 28.sp, color = Color.White)
        Text(" TV", fontSize = 28.sp, color = Purple)
        Spacer(Modifier.weight(1f))
        Text("DEMO MODE", color = Color(0xFFB8AACF), fontSize = 14.sp)
    }
}

@Composable
private fun Home(destinations: List<Destination>, open: (String) -> Unit) {
    Text("Good evening", color = Color(0xFFB8AACF), fontSize = 18.sp)
    Text("What would you like to watch?", color = Color.White, fontSize = 38.sp)
    Spacer(Modifier.height(42.dp))
    LazyRow(horizontalArrangement = Arrangement.spacedBy(20.dp)) {
        items(destinations) { item ->
            Card(
                onClick = { open(item.title) },
                modifier = Modifier.width(224.dp).height(156.dp),
                colors = CardDefaults.colors(containerColor = Panel, focusedContainerColor = Purple),
                scale = CardDefaults.scale(focusedScale = 1.08f)
            ) {
                Column(Modifier.fillMaxSize().padding(22.dp), verticalArrangement = Arrangement.SpaceBetween) {
                    Icon(item.icon, null, tint = Color.White, modifier = Modifier.size(42.dp))
                    Column {
                        Text(item.title, color = Color.White, fontSize = 23.sp)
                        Text(item.subtitle, color = Color(0xFFD1CEDA), fontSize = 13.sp)
                    }
                }
            }
        }
    }
    Spacer(Modifier.height(48.dp))
    Text("Next step", color = Color(0xFFB8AACF), fontSize = 16.sp)
    Text("Add your legal IPTV provider and start watching", color = Color.White, fontSize = 24.sp)
}

@Composable
private fun Placeholder(title: String, back: () -> Unit) {
    Text(title, color = Color.White, fontSize = 40.sp)
    Spacer(Modifier.height(16.dp))
    Text("This screen is ready for the next build.", color = Color(0xFFB8AACF), fontSize = 20.sp)
    Spacer(Modifier.height(34.dp))
    Button(onClick = back) { Text("Back to Home") }
}
