package tv.streamnest.app

import android.os.Bundle
import android.view.ViewGroup
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.MediaItem
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import androidx.tv.material3.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

private val Red = Color(0xFFE31822)
private val DeepRed = Color(0xFF680009)
private val Ink = Color(0xFF08090D)
private val Panel = Color(0xFF17191F)
private val Muted = Color(0xFFB7B8BE)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { TvShqipApp() }
    }
}

private enum class Screen { HOME, LOGIN, LIVE, FULLSCREEN, PLACEHOLDER }
private data class Provider(val server: String, val username: String, val password: String)
private data class LiveChannel(val id: Int, val name: String, val category: String, val url: String)
private data class HomeItem(val title: String, val subtitle: String, val icon: ImageVector)

@Composable
private fun TvShqipApp() {
    var screen by remember { mutableStateOf(Screen.HOME) }
    var channels by remember { mutableStateOf(emptyList<LiveChannel>()) }
    var selectedChannel by remember { mutableStateOf<LiveChannel?>(null) }
    var placeholder by remember { mutableStateOf("") }

    MaterialTheme {
        if (screen == Screen.FULLSCREEN && selectedChannel != null) {
            FullScreenPlayer(selectedChannel!!) { screen = Screen.LIVE }
        } else {
            AppBackground {
                Header()
                Spacer(Modifier.height(28.dp))
                when (screen) {
                    Screen.HOME -> HomeScreen(
                        onLive = { screen = Screen.LOGIN },
                        onOther = { placeholder = it; screen = Screen.PLACEHOLDER }
                    )
                    Screen.LOGIN -> LoginScreen(
                        onBack = { screen = Screen.HOME },
                        onConnected = {
                            channels = it
                            selectedChannel = it.firstOrNull()
                            screen = Screen.LIVE
                        }
                    )
                    Screen.LIVE -> LiveTvScreen(
                        channels = channels,
                        initialChannel = selectedChannel,
                        onSelected = { selectedChannel = it },
                        onFullScreen = { selectedChannel = it; screen = Screen.FULLSCREEN },
                        onBack = { screen = Screen.HOME },
                        onProvider = { screen = Screen.LOGIN }
                    )
                    Screen.PLACEHOLDER -> PlaceholderScreen(placeholder) { screen = Screen.HOME }
                    else -> Unit
                }
            }
        }
    }
}

@Composable
private fun AppBackground(content: @Composable ColumnScope.() -> Unit) {
    Box(
        Modifier.fillMaxSize().background(
            Brush.linearGradient(listOf(DeepRed, Ink, Ink))
        )
    ) {
        Column(
            Modifier.fillMaxSize().padding(horizontal = 46.dp, vertical = 28.dp),
            content = content
        )
    }
}

@Composable
private fun Header() {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Box(
            Modifier.size(42.dp).background(Red),
            contentAlignment = Alignment.Center
        ) {
            Icon(Icons.Default.LiveTv, null, tint = Color.Black, modifier = Modifier.size(30.dp))
        }
        Spacer(Modifier.width(12.dp))
        Text("TV", fontSize = 28.sp, color = Color.White)
        Text(" SHQIP", fontSize = 28.sp, color = Red)
        Spacer(Modifier.weight(1f))
        Text("LIVE • MOVIES • SERIES", color = Muted, fontSize = 13.sp)
    }
}

@Composable
private fun HomeScreen(onLive: () -> Unit, onOther: (String) -> Unit) {
    val items = listOf(
        HomeItem("Live TV", "Xtream channels", Icons.Default.LiveTv),
        HomeItem("Movies", "Coming next", Icons.Default.Movie),
        HomeItem("Series", "Coming next", Icons.Default.Tv),
        HomeItem("Favorites", "Coming next", Icons.Default.Favorite),
        HomeItem("Settings", "Provider login", Icons.Default.Settings)
    )
    Text("Mirembrema", color = Muted, fontSize = 18.sp)
    Text("Cfare deshironi te shikoni?", color = Color.White, fontSize = 38.sp)
    Spacer(Modifier.height(40.dp))
    LazyRow(horizontalArrangement = Arrangement.spacedBy(18.dp)) {
        items(items) { item ->
            Card(
                onClick = {
                    if (item.title == "Live TV" || item.title == "Settings") onLive()
                    else onOther(item.title)
                },
                modifier = Modifier.width(220.dp).height(154.dp),
                colors = CardDefaults.colors(containerColor = Panel, focusedContainerColor = Red),
                scale = CardDefaults.scale(focusedScale = 1.07f)
            ) {
                Column(Modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.SpaceBetween) {
                    Icon(item.icon, null, tint = Color.White, modifier = Modifier.size(40.dp))
                    Column {
                        Text(item.title, color = Color.White, fontSize = 22.sp)
                        Text(item.subtitle, color = Color(0xFFD5D5D8), fontSize = 13.sp)
                    }
                }
            }
        }
    }
    Spacer(Modifier.height(44.dp))
    Text("TV Shqip v0.2", color = Muted, fontSize = 15.sp)
    Text("Xtream Codes • Live channel player", color = Color.White, fontSize = 22.sp)
}

@Composable
private fun LoginScreen(onBack: () -> Unit, onConnected: (List<LiveChannel>) -> Unit) {
    BackHandler(onBack = onBack)
    var server by remember { mutableStateOf("") }
    var username by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var loading by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    val scope = rememberCoroutineScope()

    Row(Modifier.fillMaxSize(), horizontalArrangement = Arrangement.spacedBy(60.dp)) {
        Column(Modifier.width(570.dp)) {
            Text("Shto Xtream Codes", color = Color.White, fontSize = 34.sp)
            Text("Vendos te dhenat e ofruesit tend.", color = Muted, fontSize = 17.sp)
            Spacer(Modifier.height(24.dp))
            TvInput("Server URL  (http://server:port)", server, { server = it })
            Spacer(Modifier.height(13.dp))
            TvInput("Username", username, { username = it })
            Spacer(Modifier.height(13.dp))
            TvInput("Password", password, { password = it }, secret = true)
            Spacer(Modifier.height(20.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                Button(onClick = onBack) { Text("Back") }
                Button(
                    onClick = {
                        if (server.isBlank() || username.isBlank() || password.isBlank()) {
                            error = "Ploteso serverin, username dhe password."
                        } else {
                            loading = true
                            error = null
                            scope.launch {
                                runCatching { XtreamClient.load(Provider(server, username, password)) }
                                    .onSuccess {
                                        loading = false
                                        if (it.isEmpty()) error = "Nuk u gjeten kanale Live TV."
                                        else onConnected(it)
                                    }
                                    .onFailure {
                                        loading = false
                                        error = it.message ?: "Nuk mund te lidhet me serverin."
                                    }
                            }
                        }
                    },
                    enabled = !loading
                ) { Text(if (loading) "Connecting..." else "Connect") }
            }
            error?.let {
                Spacer(Modifier.height(14.dp))
                Text(it, color = Color(0xFFFF8A80), fontSize = 16.sp)
            }
        }
        Column(Modifier.weight(1f).padding(top = 46.dp)) {
            Icon(Icons.Default.Dns, null, tint = Red, modifier = Modifier.size(100.dp))
            Spacer(Modifier.height(20.dp))
            Text("Te dhenat ruhen vetem gjate perdorimit.", color = Color.White, fontSize = 21.sp)
            Spacer(Modifier.height(8.dp))
            Text("Nuk perfshihen ne APK dhe nuk dergohen ne GitHub.", color = Muted, fontSize = 16.sp)
        }
    }
}

@Composable
private fun TvInput(label: String, value: String, change: (String) -> Unit, secret: Boolean = false) {
    Column {
        Text(label, color = Muted, fontSize = 15.sp)
        Spacer(Modifier.height(5.dp))
        BasicTextField(
            value = value,
            onValueChange = change,
            singleLine = true,
            visualTransformation = if (secret) PasswordVisualTransformation() else VisualTransformation.None,
            cursorBrush = SolidColor(Red),
            textStyle = TextStyle(color = Color.White, fontSize = 19.sp),
            modifier = Modifier.fillMaxWidth().background(Panel).padding(horizontal = 17.dp, vertical = 14.dp)
        )
    }
}

@Composable
private fun LiveTvScreen(
    channels: List<LiveChannel>,
    initialChannel: LiveChannel?,
    onSelected: (LiveChannel) -> Unit,
    onFullScreen: (LiveChannel) -> Unit,
    onBack: () -> Unit,
    onProvider: () -> Unit
) {
    BackHandler(onBack = onBack)
    val allLabel = "Te gjitha"
    val categories = remember(channels) { listOf(allLabel) + channels.map { it.category }.filter { it.isNotBlank() }.distinct() }
    var category by remember { mutableStateOf(allLabel) }
    var selected by remember { mutableStateOf(initialChannel ?: channels.first()) }
    val filtered = remember(channels, category) {
        if (category == allLabel) channels else channels.filter { it.category == category }
    }

    Row(Modifier.fillMaxSize(), horizontalArrangement = Arrangement.spacedBy(14.dp)) {
        Column(Modifier.width(245.dp).fillMaxHeight()) {
            Text("Kategorite", color = Color.White, fontSize = 25.sp)
            Spacer(Modifier.height(12.dp))
            LazyColumn(verticalArrangement = Arrangement.spacedBy(7.dp)) {
                items(categories) { name ->
                    Card(
                        onClick = { category = name },
                        modifier = Modifier.fillMaxWidth().height(48.dp),
                        colors = CardDefaults.colors(
                            containerColor = if (name == category) DeepRed else Panel,
                            focusedContainerColor = Red
                        )
                    ) {
                        Box(Modifier.fillMaxSize().padding(horizontal = 14.dp), contentAlignment = Alignment.CenterStart) {
                            Text(name, color = Color.White, fontSize = 16.sp)
                        }
                    }
                }
            }
        }

        Column(Modifier.width(430.dp).fillMaxHeight()) {
            Text("Kanalet  ${filtered.size}", color = Color.White, fontSize = 25.sp)
            Spacer(Modifier.height(12.dp))
            LazyColumn(verticalArrangement = Arrangement.spacedBy(7.dp)) {
                items(filtered, key = { it.id }) { channel ->
                    Card(
                        onClick = { selected = channel; onSelected(channel) },
                        modifier = Modifier.fillMaxWidth().height(56.dp),
                        colors = CardDefaults.colors(
                            containerColor = if (channel.id == selected.id) DeepRed else Panel,
                            focusedContainerColor = Red
                        )
                    ) {
                        Row(
                            Modifier.fillMaxSize().padding(horizontal = 15.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(channel.id.toString(), color = Muted, fontSize = 13.sp, modifier = Modifier.width(52.dp))
                            Text(channel.name, color = Color.White, fontSize = 17.sp, maxLines = 1)
                        }
                    }
                }
            }
        }

        Column(Modifier.weight(1f).fillMaxHeight()) {
            Text(selected.name, color = Color.White, fontSize = 25.sp, maxLines = 1)
            Text(selected.category, color = Muted, fontSize = 15.sp)
            Spacer(Modifier.height(12.dp))
            PreviewPlayer(selected, Modifier.fillMaxWidth().weight(1f))
            Spacer(Modifier.height(12.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Button(onClick = { onFullScreen(selected) }) { Text("Full Screen") }
                Button(onClick = onProvider) { Text("Provider") }
                Button(onClick = onBack) { Text("Home") }
            }
        }
    }
}

@UnstableApi
@Composable
private fun PreviewPlayer(channel: LiveChannel, modifier: Modifier = Modifier) {
    val context = LocalContext.current
    val player = remember(channel.url) {
        ExoPlayer.Builder(context).build().apply {
            setMediaItem(MediaItem.fromUri(channel.url))
            prepare()
            playWhenReady = true
            volume = 0.65f
        }
    }
    DisposableEffect(player) { onDispose { player.release() } }
    AndroidView(
        factory = { ctx ->
            PlayerView(ctx).apply {
                this.player = player
                useController = false
                layoutParams = ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
            }
        },
        modifier = modifier.background(Color.Black)
    )
}

@UnstableApi
@Composable
private fun FullScreenPlayer(channel: LiveChannel, onBack: () -> Unit) {
    BackHandler(onBack = onBack)
    val context = LocalContext.current
    val player = remember(channel.url) {
        ExoPlayer.Builder(context).build().apply {
            setMediaItem(MediaItem.fromUri(channel.url))
            prepare()
            playWhenReady = true
        }
    }
    DisposableEffect(player) { onDispose { player.release() } }
    Box(Modifier.fillMaxSize().background(Color.Black)) {
        AndroidView(
            factory = { ctx ->
                PlayerView(ctx).apply {
                    this.player = player
                    useController = true
                    layoutParams = ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
                }
            },
            modifier = Modifier.fillMaxSize()
        )
        Text(
            channel.name,
            color = Color.White,
            fontSize = 21.sp,
            modifier = Modifier.align(Alignment.TopStart).background(Color(0x99000000)).padding(16.dp)
        )
    }
}

@Composable
private fun PlaceholderScreen(title: String, back: () -> Unit) {
    BackHandler(onBack = back)
    Text(title, color = Color.White, fontSize = 38.sp)
    Spacer(Modifier.height(14.dp))
    Text("Kjo pjese do te shtohet ne versionin e ardhshem.", color = Muted, fontSize = 20.sp)
    Spacer(Modifier.height(28.dp))
    Button(onClick = back) { Text("Home") }
}

private object XtreamClient {
    suspend fun load(provider: Provider): List<LiveChannel> = withContext(Dispatchers.IO) {
        val server = provider.server.trim().trimEnd('/')
        require(server.startsWith("http://") || server.startsWith("https://")) {
            "Server URL duhet te filloje me http:// ose https://"
        }
        val user = encode(provider.username)
        val pass = encode(provider.password)
        val api = "$server/player_api.php?username=$user&password=$pass"
        val auth = JSONObject(request(api))
        if (auth.optJSONObject("user_info")?.optInt("auth", 0) != 1) {
            error("Username ose password nuk u pranua.")
        }

        val categoryMap = mutableMapOf<String, String>()
        val categoryJson = JSONArray(request("$api&action=get_live_categories"))
        for (i in 0 until categoryJson.length()) {
            val item = categoryJson.getJSONObject(i)
            categoryMap[item.optString("category_id")] = item.optString("category_name")
        }

        val streams = JSONArray(request("$api&action=get_live_streams"))
        buildList {
            for (i in 0 until streams.length()) {
                val item = streams.getJSONObject(i)
                val id = item.optInt("stream_id", -1)
                if (id > 0) {
                    add(
                        LiveChannel(
                            id = id,
                            name = item.optString("name", "Channel $id"),
                            category = categoryMap[item.optString("category_id")].orEmpty(),
                            url = "$server/live/$user/$pass/$id.ts"
                        )
                    )
                }
            }
        }
    }

    private fun encode(value: String): String = URLEncoder.encode(value, "UTF-8")

    private fun request(address: String): String {
        val connection = (URL(address).openConnection() as HttpURLConnection).apply {
            connectTimeout = 15_000
            readTimeout = 30_000
            requestMethod = "GET"
            setRequestProperty("User-Agent", "TVShqip/0.2")
        }
        return try {
            val status = connection.responseCode
            if (status !in 200..299) error("Server error: HTTP $status")
            connection.inputStream.bufferedReader().use { it.readText() }
        } finally {
            connection.disconnect()
        }
    }
}
