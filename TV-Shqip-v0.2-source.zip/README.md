# TV Shqip

An original Android TV IPTV-player shell for user-supplied, legally authorized content.

## Version 0.2

- Android TV / Google TV launcher support
- Landscape TV interface
- D-pad focus and navigation
- Home cards for Live TV, Movies, Series, Favorites, and Settings
- Original Albanian red-and-black TV Shqip branding
- Xtream Codes-compatible login fields
- Live category and channel loading
- Live playback with Media3

This version intentionally contains no channels, credentials, or copyrighted media.

## Build

Open the folder in Android Studio, let Gradle sync, then build the `debug` variant. The APK is generated under `app/build/outputs/apk/debug/`.

## Next milestone

Add secure saved providers, channel search, favorites, Now/Next EPG, Movies, and Series.
