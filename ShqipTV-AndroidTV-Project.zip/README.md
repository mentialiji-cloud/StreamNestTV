# Shqip TV — Android TV / Google TV

A TV-first IPTV player starter project with:

- M3U / M3U8 playlist loading by URL
- Xtream Codes login for live TV
- Category browsing
- Favorites (hold OK on a channel)
- Google TV / Android TV D-pad navigation
- Media3 / ExoPlayer playback
- Channel Up / Down with the remote
- GitHub Actions APK build

## Build on GitHub

Push the entire project to the repository root. The included workflow builds:

`app/build/outputs/apk/debug/app-debug.apk`

The GitHub Actions artifact is named:

`ShqipTV-AndroidTV`

## Important

This is a clean-room TV interface inspired by common IPTV player layouts. It is not TiviMate code and does not copy TiviMate's proprietary UI/assets.

Use only IPTV services and playlists you are authorized to access.
