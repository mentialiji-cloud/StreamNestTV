# Add release-specific ProGuard/R8 rules here when needed.
