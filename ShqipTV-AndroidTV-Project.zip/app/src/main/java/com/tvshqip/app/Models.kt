package com.tvshqip.app

data class Channel(
    val name: String,
    val url: String,
    val group: String = "Other",
    val logo: String? = null
)

object ChannelSession {
    var channels: List<Channel> = emptyList()
    var selectedIndex: Int = 0
}
