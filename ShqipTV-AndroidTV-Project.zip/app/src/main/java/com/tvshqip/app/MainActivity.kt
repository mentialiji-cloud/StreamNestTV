package com.tvshqip.app

import android.app.AlertDialog
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import java.util.concurrent.Executors

class MainActivity : AppCompatActivity() {

    private val executor = Executors.newSingleThreadExecutor()

    private lateinit var categoriesView: RecyclerView
    private lateinit var channelsView: RecyclerView
    private lateinit var statusText: TextView
    private lateinit var categoryAdapter: CategoryAdapter
    private lateinit var channelAdapter: ChannelAdapter

    private var allChannels: List<Channel> = emptyList()
    private var visibleChannels: List<Channel> = emptyList()
    private val favorites = LinkedHashSet<String>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.decorView.systemUiVisibility =
            View.SYSTEM_UI_FLAG_FULLSCREEN or
            View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY

        loadFavorites()
        setContentView(buildUi())
    }

    private fun buildUi(): View {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.rgb(8, 10, 14))
            setPadding(26, 20, 26, 20)
        }

        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }

        val title = TextView(this).apply {
            text = "SHQIP TV"
            textSize = 28f
            setTextColor(Color.WHITE)
            setTypeface(null, android.graphics.Typeface.BOLD)
        }

        val spacer = Space(this)
        header.addView(title)
        header.addView(spacer, LinearLayout.LayoutParams(0, 1, 1f))

        val m3u = tvButton("M3U PLAYLIST")
        val xtream = tvButton("XTREAM CODES")
        m3u.setOnClickListener { showM3uDialog() }
        xtream.setOnClickListener { showXtreamDialog() }

        header.addView(m3u)
        header.addView(space(12))
        header.addView(xtream)

        statusText = TextView(this).apply {
            text = "Add an M3U playlist or Xtream Codes account"
            textSize = 15f
            setTextColor(Color.LTGRAY)
            setPadding(0, 10, 0, 12)
        }

        val content = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
        }

        categoriesView = RecyclerView(this).apply {
            layoutManager = LinearLayoutManager(this@MainActivity)
            setBackgroundColor(Color.rgb(13, 16, 21))
            descendantFocusability = ViewGroup.FOCUS_AFTER_DESCENDANTS
        }

        channelsView = RecyclerView(this).apply {
            layoutManager = LinearLayoutManager(this@MainActivity)
            setPadding(16, 0, 0, 0)
            clipToPadding = false
        }

        categoryAdapter = CategoryAdapter(emptyList()) { category ->
            filterCategory(category)
        }
        categoriesView.adapter = categoryAdapter

        channelAdapter = ChannelAdapter(
            emptyList(),
            onOpen = { _, index -> openPlayer(index) },
            onFavorite = { channel -> toggleFavorite(channel) }
        )
        channelsView.adapter = channelAdapter

        content.addView(
            categoriesView,
            LinearLayout.LayoutParams(280, LinearLayout.LayoutParams.MATCH_PARENT)
        )
        content.addView(
            channelsView,
            LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.MATCH_PARENT, 1f)
        )

        root.addView(header)
        root.addView(statusText)
        root.addView(
            content,
            LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                0,
                1f
            )
        )

        return root
    }

    private fun tvButton(label: String): Button =
        Button(this).apply {
            text = label
            isAllCaps = false
            isFocusable = true
            minHeight = 54
            setPadding(18, 6, 18, 6)
        }

    private fun space(width: Int): View =
        Space(this).apply { layoutParams = LinearLayout.LayoutParams(width, 1) }

    private fun showM3uDialog() {
        val url = EditText(this).apply {
            hint = "https://example.com/playlist.m3u"
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI
            isSingleLine = true
        }

        AlertDialog.Builder(this)
            .setTitle("Add M3U playlist")
            .setView(url)
            .setPositiveButton("Load") { _, _ ->
                val value = url.text.toString().trim()
                if (value.isNotBlank()) loadM3u(value)
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun showXtreamDialog() {
        val form = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 8, 28, 0)
        }

        val server = EditText(this).apply {
            hint = "Server: http://example.com:8080"
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI
            isSingleLine = true
        }
        val username = EditText(this).apply {
            hint = "Username"
            isSingleLine = true
        }
        val password = EditText(this).apply {
            hint = "Password"
            isSingleLine = true
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        }

        form.addView(server)
        form.addView(username)
        form.addView(password)

        AlertDialog.Builder(this)
            .setTitle("Xtream Codes")
            .setView(form)
            .setPositiveButton("Login") { _, _ ->
                loadXtream(
                    server.text.toString(),
                    username.text.toString(),
                    password.text.toString()
                )
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun loadM3u(url: String) {
        setBusy("Loading M3U playlist…")
        executor.execute {
            try {
                val text = Network.get(url)
                val channels = M3uParser.parse(text)
                if (channels.isEmpty()) throw IllegalStateException("No channels found in playlist")
                runOnUiThread { showChannels(channels, "M3U • ${channels.size} channels") }
            } catch (t: Throwable) {
                runOnUiThread { showError(t.message ?: "Unable to load playlist") }
            }
        }
    }

    private fun loadXtream(server: String, username: String, password: String) {
        if (server.isBlank() || username.isBlank() || password.isBlank()) {
            showError("Enter server, username, and password")
            return
        }

        setBusy("Signing in to Xtream Codes…")
        executor.execute {
            try {
                val result = XtreamClient.loadLive(server, username, password)
                if (result.channels.isEmpty()) {
                    throw IllegalStateException("Login worked, but no live channels were returned")
                }
                runOnUiThread {
                    showChannels(
                        result.channels,
                        "Xtream • ${result.channels.size} live channels"
                    )
                }
            } catch (t: Throwable) {
                runOnUiThread { showError(t.message ?: "Xtream login failed") }
            }
        }
    }

    private fun showChannels(channels: List<Channel>, status: String) {
        allChannels = channels.sortedWith(compareBy({ it.group.lowercase() }, { it.name.lowercase() }))
        statusText.text = status + "   •   Hold OK on a channel to add/remove Favorite"

        val groups = allChannels.map { it.group }.distinct()
        val categories = buildList {
            add("All channels")
            if (favorites.isNotEmpty()) add("Favorites")
            addAll(groups)
        }

        categoryAdapter.submit(categories)
        filterCategory("All channels")

        categoriesView.post {
            categoriesView.findViewHolderForAdapterPosition(0)?.itemView?.requestFocus()
                ?: categoriesView.requestFocus()
        }
    }

    private fun filterCategory(category: String) {
        visibleChannels = when (category) {
            "All channels" -> allChannels
            "Favorites" -> allChannels.filter { favorites.contains(it.url) }
            else -> allChannels.filter { it.group == category }
        }
        channelAdapter.submit(visibleChannels)
    }

    private fun openPlayer(index: Int) {
        if (visibleChannels.isEmpty()) return
        ChannelSession.channels = visibleChannels
        ChannelSession.selectedIndex = index.coerceIn(0, visibleChannels.lastIndex)
        startActivity(Intent(this, PlayerActivity::class.java))
    }

    private fun toggleFavorite(channel: Channel) {
        if (!favorites.add(channel.url)) favorites.remove(channel.url)
        saveFavorites()
        Toast.makeText(
            this,
            if (favorites.contains(channel.url)) "Added to Favorites" else "Removed from Favorites",
            Toast.LENGTH_SHORT
        ).show()
    }

    private fun loadFavorites() {
        val saved = getSharedPreferences("shqip_tv", MODE_PRIVATE)
            .getStringSet("favorites", emptySet()) ?: emptySet()
        favorites.addAll(saved)
    }

    private fun saveFavorites() {
        getSharedPreferences("shqip_tv", MODE_PRIVATE)
            .edit()
            .putStringSet("favorites", favorites.toSet())
            .apply()
    }

    private fun setBusy(message: String) {
        statusText.text = message
    }

    private fun showError(message: String) {
        statusText.text = message
        AlertDialog.Builder(this)
            .setTitle("Shqip TV")
            .setMessage(message)
            .setPositiveButton("OK", null)
            .show()
    }

    override fun onDestroy() {
        executor.shutdownNow()
        super.onDestroy()
    }
}
