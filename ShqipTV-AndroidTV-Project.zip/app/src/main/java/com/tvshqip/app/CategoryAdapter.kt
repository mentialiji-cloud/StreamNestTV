package com.tvshqip.app

import android.graphics.Color
import android.graphics.Typeface
import android.view.Gravity
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class CategoryAdapter(
    private var items: List<String>,
    private val onSelected: (String) -> Unit
) : RecyclerView.Adapter<CategoryAdapter.Holder>() {

    private var selected = 0

    class Holder(val text: TextView) : RecyclerView.ViewHolder(text)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): Holder {
        val tv = TextView(parent.context).apply {
            isFocusable = true
            isFocusableInTouchMode = true
            setTextColor(Color.WHITE)
            textSize = 19f
            gravity = Gravity.CENTER_VERTICAL
            setPadding(28, 10, 20, 10)
            minHeight = 58
            setBackgroundColor(Color.TRANSPARENT)
        }
        return Holder(tv)
    }

    override fun onBindViewHolder(holder: Holder, position: Int) {
        val item = items[position]
        holder.text.text = item
        holder.text.setTypeface(null, if (position == selected) Typeface.BOLD else Typeface.NORMAL)
        holder.text.setBackgroundColor(
            if (position == selected) Color.rgb(48, 54, 65) else Color.TRANSPARENT
        )

        holder.text.setOnFocusChangeListener { _, focused ->
            if (focused) {
                selected = holder.bindingAdapterPosition
                notifyDataSetChanged()
                onSelected(item)
            }
        }
        holder.text.setOnClickListener {
            selected = holder.bindingAdapterPosition
            notifyDataSetChanged()
            onSelected(item)
        }
    }

    override fun getItemCount(): Int = items.size

    fun submit(newItems: List<String>) {
        items = newItems
        selected = 0
        notifyDataSetChanged()
    }
}
