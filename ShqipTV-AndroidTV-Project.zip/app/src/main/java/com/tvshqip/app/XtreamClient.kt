package com.tvshqip.app

import org.json.JSONArray
import org.json.JSONObject

object XtreamClient {
    data class Result(
        val channels: List<Channel>,
        val accountStatus: String
    )

    fun loadLive(serverInput: String, username: String, password: String): Result {
        val server = serverInput.trim().trimEnd('/')
        require(server.startsWith("http://") || server.startsWith("https://")) {
            "Server must start with http:// or https://"
        }

        val u = Network.enc(username)
        val p = Network.enc(password)

        val authUrl = "$server/player_api.php?username=$u&password=$p"
        val auth = JSONObject(Network.get(authUrl))
        val userInfo = auth.optJSONObject("user_info")
            ?: throw IllegalStateException("Xtream login failed")

        val status = userInfo.optString("status", "Unknown")
        if (!status.equals("Active", ignoreCase = true)) {
            throw IllegalStateException("Account status: $status")
        }

        val categoriesJson = JSONArray(
            Network.get("$authUrl&action=get_live_categories")
        )
        val categories = mutableMapOf<String, String>()
        for (i in 0 until categoriesJson.length()) {
            val item = categoriesJson.optJSONObject(i) ?: continue
            categories[item.optString("category_id")] =
                item.optString("category_name", "Other")
        }

        val streamsJson = JSONArray(
            Network.get("$authUrl&action=get_live_streams")
        )

        val channels = ArrayList<Channel>(streamsJson.length())
        for (i in 0 until streamsJson.length()) {
            val item = streamsJson.optJSONObject(i) ?: continue
            val streamId = item.optInt("stream_id", -1)
            if (streamId <= 0) continue

            val categoryId = item.optString("category_id")
            val group = categories[categoryId] ?: "Other"
            val name = item.optString("name", "Channel")
            val logo = item.optString("stream_icon").takeIf { it.isNotBlank() }

            val direct = "$server/live/$u/$p/$streamId.ts"
            channels += Channel(name, direct, group, logo)
        }

        return Result(channels, status)
    }
}
