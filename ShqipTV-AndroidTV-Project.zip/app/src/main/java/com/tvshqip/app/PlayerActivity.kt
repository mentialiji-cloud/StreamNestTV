package com.tvshqip.app

import android.graphics.Color
import android.os.Bundle
import android.view.KeyEvent
import android.view.View
import android.widget.FrameLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView

class PlayerActivity : AppCompatActivity() {

    private var player: ExoPlayer? = null
    private lateinit var playerView: PlayerView
    private lateinit var channelLabel: TextView
    private var index = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        window.decorView.systemUiVisibility =
            View.SYSTEM_UI_FLAG_FULLSCREEN or
            View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY

        val root = FrameLayout(this).apply {
            setBackgroundColor(Color.BLACK)
        }

        playerView = PlayerView(this).apply {
            useController = true
            controllerAutoShow = false
            controllerShowTimeoutMs = 3000
        }

        channelLabel = TextView(this).apply {
            setTextColor(Color.WHITE)
            setBackgroundColor(0x99000000.toInt())
            textSize = 22f
            setPadding(24, 12, 24, 12)
        }

        root.addView(
            playerView,
            FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT
            )
        )
        root.addView(
            channelLabel,
            FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.WRAP_CONTENT,
                FrameLayout.LayoutParams.WRAP_CONTENT
            ).apply {
                leftMargin = 28
                topMargin = 28
            }
        )

        setContentView(root)

        index = ChannelSession.selectedIndex
        initPlayer()
        play(index)
    }

    private fun initPlayer() {
        player = ExoPlayer.Builder(this).build().also {
            playerView.player = it
            it.addListener(object : Player.Listener {
                override fun onPlayerError(error: androidx.media3.common.PlaybackException) {
                    channelLabel.text = "${currentName()}  •  Playback error"
                }
            })
        }
    }

    private fun play(newIndex: Int) {
        val channels = ChannelSession.channels
        if (channels.isEmpty()) {
            finish()
            return
        }

        index = ((newIndex % channels.size) + channels.size) % channels.size
        ChannelSession.selectedIndex = index

        val channel = channels[index]
        channelLabel.text = "${index + 1}. ${channel.name}"

        player?.apply {
            setMediaItem(MediaItem.fromUri(channel.url))
            prepare()
            playWhenReady = true
        }

        channelLabel.removeCallbacks(hideLabel)
        channelLabel.visibility = View.VISIBLE
        channelLabel.postDelayed(hideLabel, 3500)
    }

    private val hideLabel = Runnable {
        channelLabel.visibility = View.GONE
    }

    private fun currentName(): String =
        ChannelSession.channels.getOrNull(index)?.name ?: "Channel"

    override fun dispatchKeyEvent(event: KeyEvent): Boolean {
        if (event.action == KeyEvent.ACTION_DOWN) {
            when (event.keyCode) {
                KeyEvent.KEYCODE_DPAD_UP,
                KeyEvent.KEYCODE_CHANNEL_UP -> {
                    play(index + 1)
                    return true
                }

                KeyEvent.KEYCODE_DPAD_DOWN,
                KeyEvent.KEYCODE_CHANNEL_DOWN -> {
                    play(index - 1)
                    return true
                }

                KeyEvent.KEYCODE_DPAD_CENTER,
                KeyEvent.KEYCODE_ENTER -> {
                    if (playerView.isControllerFullyVisible) {
                        playerView.hideController()
                    } else {
                        playerView.showController()
                    }
                    return true
                }
            }
        }
        return super.dispatchKeyEvent(event)
    }

    override fun onStop() {
        super.onStop()
        player?.release()
        player = null
    }
}
