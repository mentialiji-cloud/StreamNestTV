package com.tvshqip.app

object M3uParser {
    private val attrRegex = Regex("""([\w-]+)="([^"]*)"""")

    fun parse(text: String): List<Channel> {
        val lines = text.lineSequence().map { it.trim() }.filter { it.isNotEmpty() }.toList()
        val channels = mutableListOf<Channel>()

        var pendingName: String? = null
        var pendingGroup = "Other"
        var pendingLogo: String? = null

        for (line in lines) {
            if (line.startsWith("#EXTINF", ignoreCase = true)) {
                val attrs = attrRegex.findAll(line).associate { it.groupValues[1] to it.groupValues[2] }
                pendingGroup = attrs["group-title"]?.ifBlank { "Other" } ?: "Other"
                pendingLogo = attrs["tvg-logo"]
                pendingName = line.substringAfterLast(",", "").trim().ifBlank {
                    attrs["tvg-name"] ?: "Channel"
                }
            } else if (!line.startsWith("#") && pendingName != null) {
                channels += Channel(
                    name = pendingName ?: "Channel",
                    url = line,
                    group = pendingGroup,
                    logo = pendingLogo
                )
                pendingName = null
                pendingGroup = "Other"
                pendingLogo = null
            }
        }

        return channels
    }
}
