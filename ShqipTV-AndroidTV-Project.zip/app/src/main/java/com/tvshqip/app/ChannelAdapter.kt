package com.tvshqip.app

import android.graphics.Color
import android.view.Gravity
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class ChannelAdapter(
    private var items: List<Channel>,
    private val onOpen: (Channel, Int) -> Unit,
    private val onFavorite: (Channel) -> Unit
) : RecyclerView.Adapter<ChannelAdapter.Holder>() {

    class Holder(val text: TextView) : RecyclerView.ViewHolder(text)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): Holder {
        val tv = TextView(parent.context).apply {
            isFocusable = true
            isFocusableInTouchMode = true
            setTextColor(Color.WHITE)
            textSize = 20f
            gravity = Gravity.CENTER_VERTICAL
            setPadding(26, 10, 26, 10)
            minHeight = 62
            setBackgroundColor(Color.rgb(20, 23, 29))
        }
        return Holder(tv)
    }

    override fun onBindViewHolder(holder: Holder, position: Int) {
        val channel = items[position]
        holder.text.text = channel.name
        holder.text.setOnFocusChangeListener { view, focused ->
            view.setBackgroundColor(
                if (focused) Color.rgb(55, 63, 77) else Color.rgb(20, 23, 29)
            )
        }
        holder.text.setOnClickListener {
            onOpen(channel, holder.bindingAdapterPosition)
        }
        holder.text.setOnLongClickListener {
            onFavorite(channel)
            true
        }
    }

    override fun getItemCount(): Int = items.size

    fun submit(newItems: List<Channel>) {
        items = newItems
        notifyDataSetChanged()
    }
}
