package com.shqiptv.app

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.graphics.Color
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.StateListDrawable
import android.os.Bundle
import android.net.Uri
import android.text.InputType
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.*
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.ConcurrentHashMap
import kotlin.concurrent.thread

class MainActivity : Activity() {
    private val bg = Color.rgb(7, 8, 12)
    private val panel = Color.rgb(20, 22, 29)
    private val card = Color.rgb(31, 34, 43)
    private val accent = Color.rgb(225, 28, 36)
    private val muted = Color.rgb(175, 180, 190)

    private val prefs by lazy { getSharedPreferences("shqip_tv", MODE_PRIVATE) }
    private var client: XtreamClient? = null
    private var profiles = mutableListOf<PlaylistProfile>()
    private var activeProfileId = ""
    private var adultUnlocked = false
    private var m3uChannels = listOf<MediaEntry>()
    private val catalogCache = ConcurrentHashMap<MediaKind, List<MediaEntry>>()
    private val categoryCache = ConcurrentHashMap<MediaKind, List<Category>>()
    private val epgCache = ConcurrentHashMap<Int, List<EpgEntry>>()
    private val imageCache = ConcurrentHashMap<String, Bitmap>()

    private var player: ExoPlayer? = null
    private var playerView: PlayerView? = null
    private var playerInfo: LinearLayout? = null
    private var playerTitle: TextView? = null
    private var playerSubtitle: TextView? = null
    private val multiViewItems = mutableListOf<MediaEntry>()
    private val multiPlayers = mutableListOf<ExoPlayer>()
    private var multiViewOpen = false
    private var multiSelected = 0
    private var playerOpen = false
    private var playingItems = listOf<MediaEntry>()
    private var playingIndex = 0
    private var atHome = true
    private var lastKind = MediaKind.LIVE
    private var lastEpgMode = false
    private var lastCatalogItems = listOf<MediaEntry>()
    private var lastCatalogCategories = listOf<Category>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        enterFullscreen()
        restoreAccount()
        val active = profiles.firstOrNull { it.id == activeProfileId }
        val savedM3u = active?.m3uUrl?.takeIf { active.type == PlaylistType.M3U }
            ?: prefs.getString("m3u_url", "").orEmpty()
        if (client == null && savedM3u.isNotBlank()) loadM3u(savedM3u, false) else showHome()
    }

    private fun restoreAccount() {
        profiles = readProfiles().toMutableList()
        activeProfileId = prefs.getString("active_profile", "").orEmpty()
        val selected = profiles.firstOrNull { it.id == activeProfileId } ?: profiles.firstOrNull()
        if (selected != null) {
            activeProfileId = selected.id
            if (selected.type == PlaylistType.XTREAM) {
                client = XtreamClient(XtreamCredentials(selected.server, selected.username, selected.password))
            }
            return
        }
        val server = prefs.getString("server", "").orEmpty()
        val username = prefs.getString("username", "").orEmpty()
        val password = prefs.getString("password", "").orEmpty()
        if (server.isNotBlank() && username.isNotBlank() && password.isNotBlank()) {
            val profile = PlaylistProfile(
                id = "xtream_${System.currentTimeMillis()}",
                name = username,
                type = PlaylistType.XTREAM,
                server = server,
                username = username,
                password = password
            )
            profiles += profile
            activeProfileId = profile.id
            saveProfiles()
            client = XtreamClient(XtreamCredentials(server, username, password))
        } else {
            val m3u = prefs.getString("m3u_url", "").orEmpty()
            if (m3u.isNotBlank()) {
                val profile = PlaylistProfile("m3u_${System.currentTimeMillis()}", "M3U Playlist", PlaylistType.M3U, m3uUrl = m3u)
                profiles += profile
                activeProfileId = profile.id
                saveProfiles()
            }
        }
    }

    private fun readProfiles(): List<PlaylistProfile> {
        val raw = prefs.getString("profiles_json", "[]").orEmpty()
        return try {
            val array = JSONArray(raw)
            buildList {
                for (index in 0 until array.length()) {
                    val item = array.optJSONObject(index) ?: continue
                    add(PlaylistProfile(
                        id = item.optString("id"),
                        name = item.optString("name", "Playlist"),
                        type = runCatching { PlaylistType.valueOf(item.optString("type")) }.getOrDefault(PlaylistType.M3U),
                        server = item.optString("server"),
                        username = item.optString("username"),
                        password = item.optString("password"),
                        m3uUrl = item.optString("m3uUrl")
                    ))
                }
            }
        } catch (_: Exception) { emptyList() }
    }

    private fun saveProfiles() {
        val array = JSONArray()
        profiles.forEach { profile ->
            array.put(JSONObject().apply {
                put("id", profile.id); put("name", profile.name); put("type", profile.type.name)
                put("server", profile.server); put("username", profile.username); put("password", profile.password)
                put("m3uUrl", profile.m3uUrl)
            })
        }
        prefs.edit().putString("profiles_json", array.toString()).putString("active_profile", activeProfileId).apply()
    }

    private fun showHome() {
        atHome = true
        playerOpen = false
        closePlayer()
        enterFullscreen()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setBackgroundColor(bg)
        }

        val rail = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(26), dp(24), dp(18), dp(24))
            background = roundedDrawable(panel, 0)
        }
        rail.addView(LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            addView(ImageView(this@MainActivity).apply {
                setImageResource(com.shqiptv.app.R.drawable.app_icon)
                scaleType = ImageView.ScaleType.CENTER_CROP
            }, LinearLayout.LayoutParams(dp(72), dp(72)))
            addView(TextView(this@MainActivity).apply {
                text = "SHQIP\nTV"
                textSize = 23f
                setTextColor(Color.WHITE)
                setTypeface(typeface, Typeface.BOLD)
                setPadding(dp(14), 0, 0, 0)
            })
        })
        rail.addView(TextView(this).apply {
            text = if (client != null) "CONNECTED" else if (m3uChannels.isNotEmpty()) "M3U READY" else "NO PLAYLIST"
            textSize = 12f
            setTextColor(if (client != null || m3uChannels.isNotEmpty()) Color.rgb(82, 210, 125) else muted)
            setTypeface(typeface, Typeface.BOLD)
            setPadding(dp(4), dp(15), 0, dp(20))
        })

        val firstButton = tvNavButton("●  Live TV", "Channels & groups") { openSection(MediaKind.LIVE, false) }
        rail.addView(firstButton)
        rail.addView(tvNavButton("▦  TV Guide", "Now and next") { openSection(MediaKind.LIVE, true) })
        rail.addView(tvNavButton("⊞  Multi-view", "Watch up to 4 channels") { openMultiView() })
        rail.addView(tvNavButton("▶  Movies", "Video on demand") { openSection(MediaKind.MOVIE, false) })
        rail.addView(tvNavButton("▣  Series", "Shows & episodes") { openSection(MediaKind.SERIES, false) })
        rail.addView(tvNavButton("★  Favorites", "Your saved items") { showFavorites() })
        rail.addView(tvNavButton("↻  Recent", "Continue watching") { showRecent() })
        rail.addView(Space(this), LinearLayout.LayoutParams(1, 0, 1f))
        rail.addView(tvNavButton("☰  Playlists", "Switch or add service") { showProfiles() })
        rail.addView(tvNavButton("⚙  Settings", "Player & parental controls") { showSettings() })

        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(42), dp(34), dp(42), dp(32))
        }
        content.addView(TextView(this).apply {
            text = "MIRË SE VINI"
            textSize = 13f
            setTextColor(accent)
            setTypeface(typeface, Typeface.BOLD)
        })
        content.addView(TextView(this).apply {
            text = "Televizioni shqiptar,\nnë një vend."
            textSize = 38f
            setTextColor(Color.WHITE)
            setTypeface(typeface, Typeface.BOLD)
            setPadding(0, dp(8), 0, dp(12))
        })
        content.addView(TextView(this).apply {
            text = if (client != null || m3uChannels.isNotEmpty()) {
                "Zgjidh Live TV, Guidën, Filmat ose Serialet nga menuja."
            } else {
                "Shto Xtream Codes ose një listë M3U për të filluar."
            }
            textSize = 18f
            setTextColor(muted)
        })

        val cards = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.BOTTOM
            setPadding(0, dp(30), 0, 0)
        }
        cards.addView(featureCard("LIVE TV", "Ndërro kanalet shpejt\nme telekomandë", accent), LinearLayout.LayoutParams(0, dp(210), 1f).apply { marginEnd = dp(16) })
        cards.addView(featureCard("EPG GUIDE", "Programi tani\ndhe më pas", Color.rgb(28, 104, 188)), LinearLayout.LayoutParams(0, dp(210), 1f).apply { marginEnd = dp(16) })
        cards.addView(featureCard("MOVIES & SERIES", "Biblioteka jote\non demand", Color.rgb(98, 55, 168)), LinearLayout.LayoutParams(0, dp(210), 1f))
        content.addView(cards, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))

        root.addView(rail, LinearLayout.LayoutParams(dp(310), ViewGroup.LayoutParams.MATCH_PARENT))
        root.addView(content, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f))
        setContentView(root)
        firstButton.post { firstButton.requestFocus() }
    }

    private fun openSection(kind: MediaKind, epgMode: Boolean) {
        if (client == null) {
            if (kind == MediaKind.LIVE && m3uChannels.isNotEmpty()) {
                val m3uCategories = m3uChannels.map { it.categoryId }.distinct().map { Category(it, it) }
                showCatalog(kind, epgMode, m3uChannels, m3uCategories)
            }
            else showSourceDialog()
            return
        }
        catalogCache[kind]?.let { showCatalog(kind, epgMode, it, categoryCache[kind].orEmpty()); return }
        showLoading("Loading ${titleFor(kind)}…")
        thread {
            try {
                val items = client!!.catalog(kind)
                val categories = client!!.categories(kind)
                catalogCache[kind] = items
                categoryCache[kind] = categories
                runOnUiThread { showCatalog(kind, epgMode, items, categories) }
            } catch (error: Exception) {
                runOnUiThread { toast("Could not load: ${error.message}"); showHome() }
            }
        }
    }

    private fun showCatalog(kind: MediaKind, epgMode: Boolean, allItems: List<MediaEntry>, categories: List<Category>) {
        atHome = false
        playerOpen = false
        closePlayer()
        lastKind = kind
        lastEpgMode = epgMode
        lastCatalogItems = allItems
        lastCatalogCategories = categories
        enterFullscreen()
        val parentalLock = prefs.getBoolean("parental_enabled", false) && !adultUnlocked
        val blockedIds = if (parentalLock) categories.filter { isAdultCategory(it.name) }.map { it.id }.toSet() else emptySet()
        val sourceCategories = categories.filterNot { it.id in blockedIds }
        val sourceItems = allItems.filterNot { it.categoryId in blockedIds }
        var visible = sourceItems
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(bg) }
        val top = header(if (epgMode) "EPG GUIDE" else titleFor(kind), true)
        top.addView(actionButton("Search") { showSearch(kind, epgMode, allItems, categories) })
        root.addView(top)

        val body = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(dp(18), dp(12), dp(18), dp(18)) }
        val categoryNames = mutableListOf("All")
        categoryNames += sourceCategories.map { it.name }
        val categoryList = ListView(this).apply {
            divider = ColorDrawable(Color.TRANSPARENT); dividerHeight = dp(6)
            selector = selectionOutline(); isVerticalScrollBarEnabled = false; isFastScrollEnabled = true
            setDrawSelectorOnTop(true)
            adapter = TileAdapter(categoryNames, dp(58), 16f)
        }
        val grid = GridView(this).apply {
            numColumns = if (kind == MediaKind.LIVE) 2 else 3
            horizontalSpacing = dp(12); verticalSpacing = dp(12)
            stretchMode = GridView.STRETCH_COLUMN_WIDTH
            selector = selectionOutline(); isVerticalScrollBarEnabled = false; isFastScrollEnabled = true
            setDrawSelectorOnTop(true)
            setPadding(dp(14), 0, dp(14), dp(16))
            adapter = MediaAdapter(visible)
        }
        val epgPanel = createEpgPanel()

        fun refresh(items: List<MediaEntry>) {
            visible = items
            grid.adapter = MediaAdapter(visible)
            if (visible.isNotEmpty()) grid.post { grid.requestFocus() }
        }
        categoryList.setOnItemClickListener { _, _, position, _ ->
            if (position == 0) refresh(sourceItems)
            else {
                val selectedId = sourceCategories[position - 1].id
                refresh(sourceItems.filter { it.categoryId == selectedId })
            }
        }
        grid.setOnItemClickListener { _, _, position, _ ->
            val selected = visible[position]
            when (selected.kind) {
                MediaKind.SERIES -> loadEpisodes(selected)
                MediaKind.LIVE -> {
                    if (epgMode && client != null && selected.directUrl.isBlank()) showChannelGuide(selected, visible, position)
                    else { playingItems = visible; playingIndex = position; openPlayer(selected) }
                }
                else -> { playingItems = visible; playingIndex = position; openPlayer(selected) }
            }
        }
        grid.setOnItemLongClickListener { _, _, position, _ -> showItemActions(visible[position], visible, position); true }
        if (kind == MediaKind.LIVE) {
            grid.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
                override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                    if (position in visible.indices) updateEpgPanel(epgPanel, visible[position])
                }
                override fun onNothingSelected(parent: AdapterView<*>?) = Unit
            }
        }
        body.addView(categoryList, LinearLayout.LayoutParams(dp(220), ViewGroup.LayoutParams.MATCH_PARENT))
        body.addView(grid, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f))
        if (kind == MediaKind.LIVE) body.addView(epgPanel, LinearLayout.LayoutParams(dp(330), ViewGroup.LayoutParams.MATCH_PARENT))
        root.addView(body, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        setContentView(root)
        categoryList.post { categoryList.requestFocus() }
    }

    private fun createEpgPanel() = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(20), dp(18), dp(20), dp(18))
        setBackgroundColor(panel)
        addView(TextView(this@MainActivity).apply { tag = "epg_title"; text = "PROGRAM GUIDE"; textSize = 21f; setTextColor(Color.WHITE); setTypeface(typeface, Typeface.BOLD) })
        addView(TextView(this@MainActivity).apply { tag = "epg_body"; text = "Focus a channel to see now and next."; textSize = 16f; setTextColor(muted); setPadding(0, dp(18), 0, 0) })
    }

    private fun updateEpgPanel(panelView: LinearLayout, channel: MediaEntry) {
        val title = panelView.findViewWithTag<TextView>("epg_title")
        val body = panelView.findViewWithTag<TextView>("epg_body")
        title.text = channel.name
        val cached = epgCache[channel.id]
        if (cached != null) { body.text = formatEpg(cached); return }
        if (client == null || channel.directUrl.isNotBlank()) { body.text = "EPG is supplied through Xtream Codes."; return }
        body.text = "Loading guide…"
        thread {
            try {
                val entries = client!!.shortEpg(channel.id)
                epgCache[channel.id] = entries
                runOnUiThread { if (title.text == channel.name) body.text = formatEpg(entries) }
            } catch (_: Exception) { runOnUiThread { if (title.text == channel.name) body.text = "No guide information available." } }
        }
    }

    private fun formatEpg(entries: List<EpgEntry>): String {
        if (entries.isEmpty()) return "No guide information available."
        val now = System.currentTimeMillis() / 1000
        val ordered = entries.filter { it.endEpoch == 0L || it.endEpoch >= now }.take(4)
        if (ordered.isEmpty()) return "No current programs."
        return ordered.joinToString("\n\n") {
            val marker = if (it.startEpoch <= now && now < it.endEpoch) "NOW" else "NEXT"
            "$marker  ${time(it.startEpoch)}–${time(it.endEpoch)}\n${it.title}\n${it.description}".trim()
        }
    }

    private fun showChannelGuide(channel: MediaEntry, channels: List<MediaEntry>, channelIndex: Int) {
        val api = client ?: return
        showLoading("Loading guide…")
        thread {
            try {
                val entries = if (channel.hasCatchup) api.fullEpg(channel.id) else api.shortEpg(channel.id)
                epgCache[channel.id] = entries
                runOnUiThread { showGuidePrograms(channel, channels, channelIndex, entries) }
            } catch (error: Exception) {
                runOnUiThread { toast("Guide unavailable: ${error.message}"); showCatalog(MediaKind.LIVE, true, channels, lastCatalogCategories) }
            }
        }
    }

    private fun showGuidePrograms(channel: MediaEntry, channels: List<MediaEntry>, channelIndex: Int, entries: List<EpgEntry>) {
        atHome = false
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(bg) }
        root.addView(header(channel.name, true))
        root.addView(TextView(this).apply {
            text = if (channel.hasCatchup) "PROGRAM GUIDE  •  ↶ Catch-up available" else "PROGRAM GUIDE"
            textSize = 16f
            setTextColor(if (channel.hasCatchup) accent else muted)
            setTypeface(typeface, Typeface.BOLD)
            setPadding(dp(34), dp(18), dp(34), dp(12))
        })
        val now = System.currentTimeMillis() / 1000
        val programs = entries.sortedBy { it.startEpoch }.filter { it.endEpoch == 0L || it.endEpoch >= now - 7 * 24 * 3600 }
        val list = ListView(this).apply {
            divider = ColorDrawable(Color.TRANSPARENT)
            dividerHeight = dp(7)
            selector = selectionOutline()
            setDrawSelectorOnTop(true)
            setPadding(dp(34), 0, dp(34), dp(24))
            adapter = ProgramAdapter(programs, now, channel.hasCatchup)
            setOnItemClickListener { _, _, position, _ ->
                val program = programs[position]
                when {
                    program.startEpoch <= now && now < program.endEpoch -> {
                        playingItems = channels; playingIndex = channelIndex; openPlayer(channel)
                    }
                    program.endEpoch <= now && channel.hasCatchup -> {
                        val catchup = channel.copy(name = "${channel.name} • ${program.title}", directUrl = client?.catchupUrl(channel, program).orEmpty())
                        playingItems = listOf(catchup); playingIndex = 0; openPlayer(catchup)
                    }
                    program.startEpoch > now -> toast("Upcoming: ${program.title}")
                    else -> toast("Catch-up is not available for this program")
                }
            }
        }
        root.addView(list, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        setContentView(root)
        val currentIndex = programs.indexOfFirst { it.startEpoch <= now && now < it.endEpoch }.coerceAtLeast(0)
        list.setSelection(currentIndex)
        list.post { list.requestFocus() }
    }

    private fun loadEpisodes(series: MediaEntry) {
        val api = client ?: return
        showLoading("Loading episodes…")
        thread {
            try {
                val episodes = api.episodes(series.id)
                runOnUiThread { showEpisodeList(series.name, episodes) }
            } catch (error: Exception) { runOnUiThread { toast("Could not load episodes: ${error.message}"); showHome() } }
        }
    }

    private fun showEpisodeList(seriesName: String, episodes: List<MediaEntry>) {
        atHome = false
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(bg) }
        root.addView(header(seriesName, true))
        val list = GridView(this).apply {
            numColumns = 3; horizontalSpacing = dp(12); verticalSpacing = dp(12)
            setPadding(dp(28), dp(18), dp(28), dp(18)); selector = selectionOutline(); isFastScrollEnabled = true
            setDrawSelectorOnTop(true)
            adapter = MediaAdapter(episodes)
            setOnItemClickListener { _, _, position, _ -> playingItems = episodes; playingIndex = position; openPlayer(episodes[position]) }
        }
        root.addView(list, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        setContentView(root); list.post { list.requestFocus() }
    }

    private fun showFavorites() {
        val favorites = prefs.getStringSet("favorites", emptySet()).orEmpty()
        val all = catalogCache.values.flatten() + m3uChannels
        val items = all.distinctBy { "${it.kind}:${it.id}:${it.directUrl}" }.filter { favoriteKey(it) in favorites }
        if (items.isEmpty()) { toast("Hold OK on any item to add a favorite"); return }
        showCatalog(MediaKind.LIVE, false, items, emptyList())
    }

    private fun showRecent() {
        val items = readHistory()
        if (items.isEmpty()) { toast("Your recently watched items will appear here"); return }
        showCatalog(items.first().kind, false, items, emptyList())
    }

    private fun addToHistory(item: MediaEntry) {
        val items = readHistory().toMutableList()
        items.removeAll { it.id == item.id && it.kind == item.kind && it.directUrl == item.directUrl }
        items.add(0, item)
        val array = JSONArray()
        items.take(30).forEach { media ->
            array.put(JSONObject().apply {
                put("id", media.id); put("name", media.name); put("categoryId", media.categoryId)
                put("kind", media.kind.name); put("icon", media.icon); put("extension", media.extension)
                put("directUrl", media.directUrl); put("hasCatchup", media.hasCatchup)
            })
        }
        prefs.edit().putString("history_json", array.toString()).apply()
    }

    private fun readHistory(): List<MediaEntry> {
        return try {
            val array = JSONArray(prefs.getString("history_json", "[]").orEmpty())
            buildList {
                for (index in 0 until array.length()) {
                    val item = array.optJSONObject(index) ?: continue
                    add(MediaEntry(
                        id = item.optInt("id"), name = item.optString("name"), categoryId = item.optString("categoryId"),
                        kind = runCatching { MediaKind.valueOf(item.optString("kind")) }.getOrDefault(MediaKind.LIVE),
                        icon = item.optString("icon"), extension = item.optString("extension", "ts"),
                        directUrl = item.optString("directUrl"), hasCatchup = item.optBoolean("hasCatchup", false)
                    ))
                }
            }
        } catch (_: Exception) { emptyList() }
    }

    private fun toggleFavorite(item: MediaEntry) {
        val set = prefs.getStringSet("favorites", emptySet()).orEmpty().toMutableSet()
        val key = favoriteKey(item)
        val added = if (key in set) { set.remove(key); false } else { set.add(key); true }
        prefs.edit().putStringSet("favorites", set).apply()
        toast(if (added) "Added to favorites" else "Removed from favorites")
    }

    private fun showItemActions(item: MediaEntry, items: List<MediaEntry>, position: Int) {
        val choices = mutableListOf("Play", "Add/remove favorite")
        if (item.kind == MediaKind.LIVE) {
            choices += if (multiViewItems.any { it.id == item.id && it.directUrl == item.directUrl }) "Remove from Multi-view" else "Add to Multi-view"
            if (multiViewItems.size >= 2) choices += "Open Multi-view"
        }
        AlertDialog.Builder(this).setTitle(item.name).setItems(choices.toTypedArray()) { _, which ->
            when (choices[which]) {
                "Play" -> { playingItems = items; playingIndex = position; openPlayer(item) }
                "Add/remove favorite" -> toggleFavorite(item)
                "Add to Multi-view" -> {
                    if (multiViewItems.size >= 4) toast("Multi-view supports up to 4 channels")
                    else { multiViewItems += item; toast("Added ${item.name} to Multi-view") }
                }
                "Remove from Multi-view" -> { multiViewItems.removeAll { it.id == item.id && it.directUrl == item.directUrl }; toast("Removed from Multi-view") }
                "Open Multi-view" -> openMultiView()
            }
        }.show()
    }

    private fun openMultiView() {
        if (multiViewItems.size < 2) {
            toast("Long-press at least 2 live channels and add them to Multi-view")
            if (client != null || m3uChannels.isNotEmpty()) openSection(MediaKind.LIVE, false)
            return
        }
        closePlayer()
        playerOpen = true
        multiViewOpen = true
        multiSelected = 0
        enterFullscreen()
        val grid = GridLayout(this).apply {
            columnCount = 2
            rowCount = if (multiViewItems.size <= 2) 1 else 2
            setBackgroundColor(Color.BLACK)
        }
        multiViewItems.take(4).forEachIndexed { index, item ->
            val url = if (item.directUrl.isNotBlank()) item.directUrl else client?.streamUrl(item).orEmpty()
            val panel = FrameLayout(this).apply { background = roundedDrawable(Color.BLACK, if (index == 0) accent else Color.DKGRAY) }
            val view = PlayerView(this).apply { useController = false; setBackgroundColor(Color.BLACK) }
            val streamPlayer = ExoPlayer.Builder(this).build().apply {
                volume = if (index == 0) 1f else 0f
                setMediaItem(MediaItem.fromUri(url)); prepare(); playWhenReady = true
            }
            view.player = streamPlayer
            multiPlayers += streamPlayer
            panel.addView(view, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
            panel.addView(TextView(this).apply {
                text = item.name
                textSize = 16f
                setTextColor(Color.WHITE)
                setTypeface(typeface, Typeface.BOLD)
                setPadding(dp(14), dp(8), dp(14), dp(8))
                background = roundedDrawable(Color.argb(190, 8, 9, 12), 0)
            }, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM))
            grid.addView(panel, GridLayout.LayoutParams().apply {
                width = 0; height = 0
                columnSpec = GridLayout.spec(index % 2, 1f)
                rowSpec = GridLayout.spec(index / 2, 1f)
                setMargins(dp(3), dp(3), dp(3), dp(3))
            })
        }
        setContentView(grid)
        toast("Multi-view • arrows change audio • BACK returns")
    }

    private fun selectMultiAudio(delta: Int) {
        if (multiPlayers.isEmpty()) return
        multiSelected = (multiSelected + delta + multiPlayers.size) % multiPlayers.size
        multiPlayers.forEachIndexed { index, exoPlayer -> exoPlayer.volume = if (index == multiSelected) 1f else 0f }
        toast("Audio: ${multiViewItems.getOrNull(multiSelected)?.name.orEmpty()}")
    }

    private fun favoriteKey(item: MediaEntry) = "${item.kind}:${item.id}:${item.directUrl}"

    private fun isAdultCategory(name: String): Boolean {
        val value = name.lowercase(Locale.getDefault())
        return listOf("adult", "xxx", "18+", "porn", "erotic", "mature", "të rritur", "te rritur").any { it in value }
    }

    private fun showSearch(kind: MediaKind, epgMode: Boolean, items: List<MediaEntry>, categories: List<Category>) {
        val field = input("Search", "")
        AlertDialog.Builder(this).setTitle("Search ${titleFor(kind)}").setView(field)
            .setPositiveButton("Search") { _, _ ->
                val query = field.text.toString().trim()
                showCatalog(kind, epgMode, items.filter { it.name.contains(query, true) }, categories)
            }.setNegativeButton("Cancel", null).show()
    }

    private fun showProfiles() {
        atHome = false
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(bg)
            setPadding(dp(48), dp(30), dp(48), dp(34))
        }
        root.addView(TextView(this).apply {
            text = "PLAYLISTS"
            textSize = 33f
            setTextColor(Color.WHITE)
            setTypeface(typeface, Typeface.BOLD)
        })
        root.addView(TextView(this).apply {
            text = "Switch between your saved Xtream Codes and M3U services."
            textSize = 17f
            setTextColor(muted)
            setPadding(0, dp(7), 0, dp(22))
        })
        val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        profiles.forEach { profile ->
            val active = profile.id == activeProfileId
            list.addView(TextView(this).apply {
                text = "${if (active) "●" else "○"}  ${profile.name}\n${profile.type.name}"
                textSize = 19f
                setTextColor(Color.WHITE)
                setTypeface(typeface, Typeface.BOLD)
                gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(22), dp(10), dp(18), dp(10))
                isFocusable = true
                background = focusBackground(if (active) Color.rgb(55, 24, 28) else card)
                setOnClickListener { switchProfile(profile) }
            }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(78)).apply { bottomMargin = dp(8) })
        }
        root.addView(ScrollView(this).apply { addView(list) }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        val actions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val add = actionButton("＋ Add playlist") { showSourceScreen() }
        actions.addView(add, LinearLayout.LayoutParams(dp(210), dp(62)).apply { marginEnd = dp(12) })
        if (profiles.isNotEmpty()) {
            actions.addView(actionButton("Remove active") { removeActiveProfile() }, LinearLayout.LayoutParams(dp(200), dp(62)).apply { marginEnd = dp(12) })
        }
        actions.addView(actionButton("← Home") { showHome() }, LinearLayout.LayoutParams(dp(150), dp(62)))
        root.addView(actions)
        setContentView(root)
        (list.getChildAt(0) ?: add).post { (list.getChildAt(0) ?: add).requestFocus() }
    }

    private fun switchProfile(profile: PlaylistProfile) {
        activeProfileId = profile.id
        saveProfiles()
        catalogCache.clear(); categoryCache.clear(); epgCache.clear(); m3uChannels = emptyList()
        if (profile.type == PlaylistType.XTREAM) {
            client = XtreamClient(XtreamCredentials(profile.server, profile.username, profile.password))
            showHome()
        } else {
            client = null
            loadM3u(profile.m3uUrl, false)
        }
    }

    private fun removeActiveProfile() {
        profiles.removeAll { it.id == activeProfileId }
        activeProfileId = profiles.firstOrNull()?.id.orEmpty()
        saveProfiles()
        if (profiles.isEmpty()) {
            prefs.edit().remove("server").remove("username").remove("password").remove("m3u_url").apply()
        }
        client = null; m3uChannels = emptyList(); catalogCache.clear(); categoryCache.clear(); epgCache.clear()
        profiles.firstOrNull()?.let { switchProfile(it) } ?: showHome()
    }

    private fun showSettings() {
        atHome = false
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(bg)
            setPadding(dp(50), dp(32), dp(50), dp(36))
        }
        root.addView(TextView(this).apply {
            text = "SETTINGS"
            textSize = 34f
            setTextColor(Color.WHITE)
            setTypeface(typeface, Typeface.BOLD)
        })
        root.addView(TextView(this).apply {
            text = "Playback, privacy and parental controls"
            textSize = 17f
            setTextColor(muted)
            setPadding(0, dp(7), 0, dp(24))
        })
        val parentalOn = prefs.getBoolean("parental_enabled", false)
        val first = settingButton(
            "Parental controls",
            if (parentalOn) "ON • Adult groups are hidden" else "OFF • Adult groups are visible"
        ) {
            prefs.edit().putBoolean("parental_enabled", !parentalOn).apply()
            adultUnlocked = false
            showSettings()
        }
        root.addView(first)
        root.addView(settingButton("Set parental PIN", if (prefs.getString("parental_pin", "").isNullOrBlank()) "No PIN configured" else "PIN configured") { showPinSetup() })
        if (parentalOn) root.addView(settingButton("Unlock adult groups", if (adultUnlocked) "Unlocked for this session" else "Enter PIN") { showPinUnlock() })
        root.addView(settingButton("Clear recent history", "Remove watched items from this device") {
            prefs.edit().remove("history_json").apply(); toast("Recent history cleared")
        })
        root.addView(settingButton("Refresh active playlist", "Reload categories, channels and guide") {
            catalogCache.clear(); categoryCache.clear(); epgCache.clear()
            val profile = profiles.firstOrNull { it.id == activeProfileId }
            if (profile?.type == PlaylistType.M3U) loadM3u(profile.m3uUrl, false) else showHome()
        })
        val externalOn = prefs.getBoolean("external_player", false)
        root.addView(settingButton("External player", if (externalOn) "ON • Open streams in another player" else "OFF • Use the built-in player") {
            prefs.edit().putBoolean("external_player", !externalOn).apply(); showSettings()
        })
        val scale = prefs.getString("video_scale", "FIT").orEmpty()
        root.addView(settingButton("Video scale", scale) {
            val next = when (scale) { "FIT" -> "FILL"; "FILL" -> "ZOOM"; else -> "FIT" }
            prefs.edit().putString("video_scale", next).apply(); showSettings()
        })
        root.addView(Space(this), LinearLayout.LayoutParams(1, 0, 1f))
        root.addView(actionButton("← Back to home") { showHome() }, LinearLayout.LayoutParams(dp(230), dp(62)))
        setContentView(root)
        first.post { first.requestFocus() }
    }

    private fun settingButton(title: String, detail: String, action: () -> Unit) = TextView(this).apply {
        text = "$title\n$detail"
        textSize = 14.5f
        setTextColor(Color.WHITE)
        setTypeface(typeface, Typeface.BOLD)
        gravity = Gravity.CENTER_VERTICAL
        setPadding(dp(22), dp(9), dp(18), dp(9))
        isFocusable = true
        background = focusBackground(card)
        setOnClickListener { action() }
        layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(62)).apply { bottomMargin = dp(7) }
    }

    private fun showPinSetup() {
        val pin = input("4-digit PIN", "").apply { inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_VARIATION_PASSWORD }
        AlertDialog.Builder(this).setTitle("Set parental PIN").setView(pin)
            .setPositiveButton("Save") { _, _ ->
                val value = pin.text.toString().filter { it.isDigit() }.take(4)
                if (value.length == 4) prefs.edit().putString("parental_pin", value).apply() else toast("PIN must contain 4 digits")
            }.setNegativeButton("Cancel", null).show()
    }

    private fun showPinUnlock() {
        val saved = prefs.getString("parental_pin", "").orEmpty()
        if (saved.isBlank()) { showPinSetup(); return }
        val pin = input("PIN", "").apply { inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_VARIATION_PASSWORD }
        AlertDialog.Builder(this).setTitle("Unlock adult groups").setView(pin)
            .setPositiveButton("Unlock") { _, _ ->
                adultUnlocked = pin.text.toString() == saved
                toast(if (adultUnlocked) "Adult groups unlocked" else "Incorrect PIN")
            }.setNegativeButton("Cancel", null).show()
    }

    private fun showSourceDialog() = showSourceScreen()

    private fun showSourceScreen() {
        atHome = false
        enterFullscreen()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(bg)
            setPadding(dp(54), dp(34), dp(54), dp(38))
        }
        root.addView(TextView(this).apply {
            text = "ADD PLAYLIST"
            textSize = 34f
            setTextColor(Color.WHITE)
            setTypeface(typeface, Typeface.BOLD)
        })
        root.addView(TextView(this).apply {
            text = "Use only a service or playlist you are authorized to access."
            textSize = 17f
            setTextColor(muted)
            setPadding(0, dp(8), 0, dp(28))
        })
        val options = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val xtream = sourceCard("XTREAM CODES", "Server URL, username and password") { showXtreamLogin() }
        val m3u = sourceCard("M3U PLAYLIST", "Direct playlist URL") { showM3uLogin() }
        options.addView(xtream, LinearLayout.LayoutParams(0, dp(250), 1f).apply { marginEnd = dp(20) })
        options.addView(m3u, LinearLayout.LayoutParams(0, dp(250), 1f))
        root.addView(options, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        root.addView(actionButton("← Back to home") { showHome() }, LinearLayout.LayoutParams(dp(230), dp(60)))
        setContentView(root)
        xtream.post { xtream.requestFocus() }
    }

    private fun showXtreamLogin() {
        atHome = false
        val root = loginShell("XTREAM CODES", "Enter the details supplied by your TV provider.")
        val form = root.findViewWithTag<LinearLayout>("form")
        val server = tvInput("Server URL  •  http://server:port", prefs.getString("server", "").orEmpty())
        val username = tvInput("Username", prefs.getString("username", "").orEmpty())
        val password = tvInput("Password", prefs.getString("password", "").orEmpty()).apply {
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        }
        form.addView(server, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(66)).apply { bottomMargin = dp(12) })
        form.addView(username, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(66)).apply { bottomMargin = dp(12) })
        form.addView(password, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(66)).apply { bottomMargin = dp(20) })
        val buttons = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val connect = actionButton("Connect") {
            connectXtream(XtreamCredentials(server.text.toString(), username.text.toString(), password.text.toString()))
        }
        buttons.addView(connect, LinearLayout.LayoutParams(dp(180), dp(62)).apply { marginEnd = dp(12) })
        buttons.addView(actionButton("Cancel") { showSourceScreen() }, LinearLayout.LayoutParams(dp(150), dp(62)))
        form.addView(buttons)
        setContentView(root)
        server.post { server.requestFocus() }
    }

    private fun connectXtream(credentials: XtreamCredentials) {
        showLoading("Connecting…")
        thread {
            try {
                val newClient = XtreamClient(credentials)
                if (!newClient.authenticate()) error("Login was rejected")
                client = newClient; catalogCache.clear(); categoryCache.clear(); epgCache.clear()
                val existing = profiles.firstOrNull {
                    it.type == PlaylistType.XTREAM && it.server.trimEnd('/') == credentials.server.trim().trimEnd('/') && it.username == credentials.username.trim()
                }
                val profile = PlaylistProfile(
                    id = existing?.id ?: "xtream_${System.currentTimeMillis()}",
                    name = credentials.username.trim(),
                    type = PlaylistType.XTREAM,
                    server = credentials.server.trim().trimEnd('/'),
                    username = credentials.username.trim(),
                    password = credentials.password
                )
                profiles.removeAll { it.id == profile.id }
                profiles += profile
                activeProfileId = profile.id
                saveProfiles()
                prefs.edit().putString("server", credentials.server.trim().trimEnd('/'))
                    .putString("username", credentials.username.trim()).putString("password", credentials.password).apply()
                runOnUiThread { toast("Connected"); showHome() }
            } catch (error: Exception) { runOnUiThread { toast("Login failed: ${error.message}"); showHome() } }
        }
    }

    private fun showM3uLogin() {
        atHome = false
        val root = loginShell("M3U PLAYLIST", "Enter the direct URL for your authorized playlist.")
        val form = root.findViewWithTag<LinearLayout>("form")
        val field = tvInput("https://provider.example/playlist.m3u", prefs.getString("m3u_url", "").orEmpty())
        form.addView(field, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(66)).apply { bottomMargin = dp(20) })
        val buttons = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        buttons.addView(actionButton("Load playlist") { loadM3u(field.text.toString().trim()) }, LinearLayout.LayoutParams(dp(210), dp(62)).apply { marginEnd = dp(12) })
        buttons.addView(actionButton("Cancel") { showSourceScreen() }, LinearLayout.LayoutParams(dp(150), dp(62)))
        form.addView(buttons)
        setContentView(root)
        field.post { field.requestFocus() }
    }

    private fun loadM3u(address: String, saveAsProfile: Boolean = true) {
        if (address.isBlank()) return
        showLoading("Loading M3U…")
        thread {
            try {
                val connection = URL(address).openConnection() as HttpURLConnection
                connection.connectTimeout = 12_000; connection.readTimeout = 25_000
                connection.setRequestProperty("User-Agent", "ShqipTV/2.0")
                val text = connection.inputStream.bufferedReader().use { it.readText() }
                connection.disconnect()
                m3uChannels = parseM3u(text)
                client = null
                if (saveAsProfile) {
                    val existing = profiles.firstOrNull { it.type == PlaylistType.M3U && it.m3uUrl == address }
                    val profile = PlaylistProfile(
                        id = existing?.id ?: "m3u_${System.currentTimeMillis()}",
                        name = runCatching { URL(address).host }.getOrDefault("M3U Playlist").ifBlank { "M3U Playlist" },
                        type = PlaylistType.M3U,
                        m3uUrl = address
                    )
                    profiles.removeAll { it.id == profile.id }
                    profiles += profile
                    activeProfileId = profile.id
                    saveProfiles()
                }
                prefs.edit().putString("m3u_url", address).apply()
                runOnUiThread { toast("${m3uChannels.size} channels loaded"); showHome() }
            } catch (error: Exception) { runOnUiThread { toast("M3U error: ${error.message}"); showHome() } }
        }
    }

    private fun parseM3u(text: String): List<MediaEntry> {
        val result = mutableListOf<MediaEntry>(); var name = "Channel"; var group = "Other"; var id = 1
        text.lineSequence().forEach { raw ->
            val line = raw.trim()
            if (line.startsWith("#EXTINF", true)) {
                name = line.substringAfterLast(',').trim().ifBlank { "Channel" }
                group = Regex("""group-title\s*=\s*"([^"]*)"""", RegexOption.IGNORE_CASE)
                    .find(line)?.groupValues?.getOrNull(1)?.ifBlank { "Other" } ?: "Other"
            } else if (line.isNotBlank() && !line.startsWith("#")) {
                result += MediaEntry(id++, name, group, MediaKind.LIVE, directUrl = line)
            }
        }
        return result
    }

    private fun openPlayer(item: MediaEntry) {
        val url = if (item.directUrl.isNotBlank()) item.directUrl else client?.streamUrl(item).orEmpty()
        if (url.isBlank()) { toast("Stream URL unavailable"); return }
        addToHistory(item)
        if (prefs.getBoolean("external_player", false)) {
            try {
                startActivity(Intent(Intent.ACTION_VIEW).apply { setDataAndType(Uri.parse(url), "video/*") })
                return
            } catch (_: Exception) { toast("No external player is installed; using built-in player") }
        }
        closePlayer()
        playerOpen = true; enterFullscreen()
        player = ExoPlayer.Builder(this).build()
        playerView = PlayerView(this).apply {
            setBackgroundColor(Color.BLACK); useController = true; controllerAutoShow = false
            resizeMode = when (prefs.getString("video_scale", "FIT")) {
                "FILL" -> AspectRatioFrameLayout.RESIZE_MODE_FILL
                "ZOOM" -> AspectRatioFrameLayout.RESIZE_MODE_ZOOM
                else -> AspectRatioFrameLayout.RESIZE_MODE_FIT
            }
            player = this@MainActivity.player
        }
        val root = FrameLayout(this).apply { setBackgroundColor(Color.BLACK) }
        root.addView(playerView, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        val info = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(30), dp(18), dp(30), dp(20))
            background = roundedDrawable(Color.argb(225, 10, 12, 17), accent)
            val titleView = TextView(this@MainActivity).apply {
                text = if (item.hasCatchup) "↶  ${item.name}" else item.name
                textSize = 25f
                setTextColor(Color.WHITE)
                setTypeface(typeface, Typeface.BOLD)
            }
            playerTitle = titleView
            addView(titleView)
            val subtitleView = TextView(this@MainActivity).apply {
                text = "▲/▼ or CH changes channel  •  OK shows controls  •  BACK returns home"
                textSize = 15f
                setTextColor(muted)
                setPadding(0, dp(6), 0, 0)
            }
            playerSubtitle = subtitleView
            addView(subtitleView)
        }
        playerInfo = info
        root.addView(info, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM).apply {
            setMargins(dp(34), 0, dp(34), dp(34))
        })
        setContentView(root)
        player?.apply { setMediaItem(MediaItem.fromUri(url)); prepare(); playWhenReady = true }
        showPlayerOverlay(item)
    }

    private fun changeChannel(delta: Int) {
        if (playingItems.isEmpty()) return
        playingIndex = (playingIndex + delta + playingItems.size) % playingItems.size
        val next = playingItems[playingIndex]
        if (next.kind == MediaKind.SERIES) return
        val url = if (next.directUrl.isNotBlank()) next.directUrl else client?.streamUrl(next).orEmpty()
        player?.apply { stop(); clearMediaItems(); setMediaItem(MediaItem.fromUri(url)); prepare(); playWhenReady = true }
        showPlayerOverlay(next)
    }

    override fun dispatchKeyEvent(event: KeyEvent): Boolean {
        if (playerOpen && event.action == KeyEvent.ACTION_DOWN) {
            if (multiViewOpen) {
                when (event.keyCode) {
                    KeyEvent.KEYCODE_DPAD_LEFT, KeyEvent.KEYCODE_DPAD_UP, KeyEvent.KEYCODE_CHANNEL_UP -> { selectMultiAudio(-1); return true }
                    KeyEvent.KEYCODE_DPAD_RIGHT, KeyEvent.KEYCODE_DPAD_DOWN, KeyEvent.KEYCODE_CHANNEL_DOWN,
                    KeyEvent.KEYCODE_DPAD_CENTER, KeyEvent.KEYCODE_ENTER -> { selectMultiAudio(1); return true }
                    KeyEvent.KEYCODE_BACK -> {
                        if (lastCatalogItems.isNotEmpty()) showCatalog(lastKind, lastEpgMode, lastCatalogItems, lastCatalogCategories) else showHome()
                        return true
                    }
                }
            }
            when (event.keyCode) {
                KeyEvent.KEYCODE_DPAD_UP, KeyEvent.KEYCODE_DPAD_LEFT,
                KeyEvent.KEYCODE_CHANNEL_UP -> { changeChannel(-1); return true }
                KeyEvent.KEYCODE_DPAD_DOWN, KeyEvent.KEYCODE_DPAD_RIGHT,
                KeyEvent.KEYCODE_CHANNEL_DOWN -> { changeChannel(1); return true }
                KeyEvent.KEYCODE_DPAD_CENTER, KeyEvent.KEYCODE_ENTER -> {
                    playerView?.showController(); playingItems.getOrNull(playingIndex)?.let { showPlayerOverlay(it) }; return true
                }
                KeyEvent.KEYCODE_BACK -> {
                    if (lastCatalogItems.isNotEmpty()) showCatalog(lastKind, lastEpgMode, lastCatalogItems, lastCatalogCategories)
                    else showHome()
                    return true
                }
            }
        }
        return super.dispatchKeyEvent(event)
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() { if (atHome) super.onBackPressed() else showHome() }

    private fun header(title: String, back: Boolean) = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
        setPadding(dp(22), dp(14), dp(22), dp(14)); setBackgroundColor(panel)
        if (back) addView(actionButton("← Home") { showHome() })
        addView(TextView(this@MainActivity).apply {
            text = title; textSize = 27f; setTextColor(Color.WHITE); setTypeface(typeface, Typeface.BOLD)
            setPadding(if (back) dp(20) else 0, 0, 0, 0)
        })
        addView(Space(this@MainActivity), LinearLayout.LayoutParams(0, 1, 1f))
        addView(TextView(this@MainActivity).apply { text = "AL"; textSize = 18f; setTextColor(accent); setTypeface(typeface, Typeface.BOLD) })
    }

    private fun tvNavButton(label: String, subtitle: String, action: () -> Unit) = TextView(this).apply {
        text = "$label\n$subtitle"
        textSize = 14.5f
        setTextColor(Color.WHITE)
        setTypeface(typeface, Typeface.BOLD)
        gravity = Gravity.CENTER_VERTICAL
        setPadding(dp(18), dp(6), dp(12), dp(6))
        isFocusable = true
        isFocusableInTouchMode = true
        background = focusBackground(Color.TRANSPARENT)
        setOnClickListener { action() }
        setOnFocusChangeListener { view, focused ->
            view.animate().translationX(if (focused) dp(8).toFloat() else 0f).setDuration(90).start()
        }
        layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(56)).apply { bottomMargin = dp(3) }
    }

    private fun featureCard(title: String, description: String, color: Int) = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        gravity = Gravity.BOTTOM
        setPadding(dp(24), dp(22), dp(24), dp(24))
        background = roundedDrawable(color, 0)
        addView(TextView(this@MainActivity).apply {
            text = title
            textSize = 22f
            setTextColor(Color.WHITE)
            setTypeface(typeface, Typeface.BOLD)
        })
        addView(TextView(this@MainActivity).apply {
            text = description
            textSize = 16f
            setTextColor(Color.WHITE)
            setPadding(0, dp(8), 0, 0)
        })
    }

    private fun sourceCard(title: String, description: String, action: () -> Unit) = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        gravity = Gravity.CENTER_VERTICAL
        setPadding(dp(34), dp(24), dp(34), dp(24))
        isFocusable = true
        isFocusableInTouchMode = true
        background = focusBackground(card)
        addView(TextView(this@MainActivity).apply {
            text = title
            textSize = 28f
            setTextColor(Color.WHITE)
            setTypeface(typeface, Typeface.BOLD)
        })
        addView(TextView(this@MainActivity).apply {
            text = description
            textSize = 18f
            setTextColor(muted)
            setPadding(0, dp(12), 0, 0)
        })
        setOnClickListener { action() }
        setOnFocusChangeListener { view, focused ->
            view.animate().scaleX(if (focused) 1.025f else 1f).scaleY(if (focused) 1.025f else 1f).setDuration(100).start()
        }
    }

    private fun loginShell(title: String, description: String) = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        gravity = Gravity.CENTER
        setPadding(dp(52), dp(34), dp(52), dp(34))
        setBackgroundColor(bg)
        addView(LinearLayout(this@MainActivity).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(38), dp(30), dp(38), dp(34))
            background = roundedDrawable(panel, 0)
            addView(TextView(this@MainActivity).apply {
                text = title
                textSize = 31f
                setTextColor(Color.WHITE)
                setTypeface(typeface, Typeface.BOLD)
            })
            addView(TextView(this@MainActivity).apply {
                text = description
                textSize = 16f
                setTextColor(muted)
                setPadding(0, dp(6), 0, dp(22))
            })
            addView(LinearLayout(this@MainActivity).apply {
                tag = "form"
                orientation = LinearLayout.VERTICAL
            })
        }, LinearLayout.LayoutParams(dp(720), ViewGroup.LayoutParams.WRAP_CONTENT))
    }

    private fun tvInput(hintText: String, value: String) = EditText(this).apply {
        hint = hintText
        setText(value)
        textSize = 18f
        setTextColor(Color.WHITE)
        setHintTextColor(muted)
        setSingleLine(true)
        inputType = InputType.TYPE_CLASS_TEXT
        setPadding(dp(18), 0, dp(18), 0)
        background = focusBackground(card)
    }

    private fun actionButton(label: String, action: () -> Unit) = Button(this).apply {
        text = label; textSize = 15f; setTextColor(Color.WHITE); isAllCaps = false
        isFocusable = true; background = focusBackground(card); setOnClickListener { action() }
    }

    private fun input(hintText: String, value: String) = EditText(this).apply {
        hint = hintText; setText(value); setSingleLine(true); inputType = InputType.TYPE_CLASS_TEXT
    }

    private fun showLoading(textValue: String) {
        setContentView(TextView(this).apply {
            text = textValue; textSize = 25f; setTextColor(Color.WHITE); gravity = Gravity.CENTER; setBackgroundColor(bg)
        })
    }

    private fun titleFor(kind: MediaKind) = when (kind) {
        MediaKind.LIVE -> "LIVE TV"; MediaKind.MOVIE -> "MOVIES"; MediaKind.SERIES -> "SERIES"; MediaKind.EPISODE -> "EPISODES"
    }

    private fun time(epoch: Long): String = if (epoch <= 0) "--:--" else SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date(epoch * 1000))

    private fun enterFullscreen() {
        window.addFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN)
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
    }

    private fun leaveFullscreen() {
        playerOpen = false; window.clearFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN)
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_VISIBLE
    }

    private fun showPlayerOverlay(item: MediaEntry) {
        playerTitle?.text = item.name
        playerSubtitle?.text = "▲/▼ or CH changes channel  •  OK shows controls  •  BACK returns to guide"
        if (item.kind == MediaKind.LIVE && client != null && item.directUrl.isBlank()) {
            val cached = epgCache[item.id]
            if (cached != null) updatePlayerEpg(item, cached)
            else thread {
                try {
                    val entries = client!!.shortEpg(item.id)
                    epgCache[item.id] = entries
                    runOnUiThread { if (playingItems.getOrNull(playingIndex)?.id == item.id) updatePlayerEpg(item, entries) }
                } catch (_: Exception) { Unit }
            }
        }
        playerInfo?.apply {
            animate().cancel()
            alpha = 1f
            visibility = View.VISIBLE
            postDelayed({ if (playerOpen) animate().alpha(0f).setDuration(300).withEndAction { visibility = View.GONE }.start() }, 3200)
        }
    }

    private fun updatePlayerEpg(item: MediaEntry, entries: List<EpgEntry>) {
        if (playerTitle?.text != item.name) return
        val now = System.currentTimeMillis() / 1000
        val current = entries.firstOrNull { it.startEpoch <= now && now < it.endEpoch }
        playerSubtitle?.text = if (current != null) {
            "NOW  ${time(current.startEpoch)}–${time(current.endEpoch)}  •  ${current.title}"
        } else {
            "▲/▼ or CH changes channel  •  OK shows controls  •  BACK returns to guide"
        }
    }

    private fun closePlayer() {
        playerView?.player = null
        player?.release()
        multiPlayers.forEach { it.release() }
        multiPlayers.clear()
        multiViewOpen = false
        player = null
        playerView = null
        playerInfo = null
        playerTitle = null
        playerSubtitle = null
    }
    override fun onDestroy() { closePlayer(); super.onDestroy() }
    private fun toast(message: String) = Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()

    private fun loadImage(address: String, target: ImageView) {
        if (address.isBlank()) return
        target.tag = address
        imageCache[address]?.let { target.setImageBitmap(it); return }
        thread {
            try {
                val connection = URL(address).openConnection() as HttpURLConnection
                connection.connectTimeout = 7_000
                connection.readTimeout = 10_000
                connection.setRequestProperty("User-Agent", "ShqipTV/5.0")
                val bitmap = connection.inputStream.use { BitmapFactory.decodeStream(it) }
                connection.disconnect()
                if (bitmap != null) {
                    imageCache[address] = bitmap
                    runOnUiThread { if (target.tag == address) target.setImageBitmap(bitmap) }
                }
            } catch (_: Exception) { Unit }
        }
    }

    private fun roundedDrawable(fill: Int, strokeColor: Int) = GradientDrawable().apply {
        setColor(fill)
        cornerRadius = dp(10).toFloat()
        if (strokeColor != 0) setStroke(dp(3), strokeColor)
    }

    private fun focusBackground(normal: Int) = StateListDrawable().apply {
        addState(intArrayOf(android.R.attr.state_focused), roundedDrawable(accent, Color.WHITE))
        addState(intArrayOf(android.R.attr.state_pressed), roundedDrawable(accent, Color.WHITE))
        addState(intArrayOf(), roundedDrawable(normal, 0))
    }

    private fun selectionOutline() = GradientDrawable().apply {
        setColor(Color.TRANSPARENT)
        setStroke(dp(5), accent)
        cornerRadius = dp(8).toFloat()
    }

    inner class TileAdapter(private val labels: List<String>, private val height: Int, private val size: Float) : BaseAdapter() {
        override fun getCount() = labels.size
        override fun getItem(position: Int) = labels[position]
        override fun getItemId(position: Int) = position.toLong()
        override fun getView(position: Int, old: View?, parent: ViewGroup?) = (old as? TextView ?: TextView(this@MainActivity)).apply {
            text = labels[position]; textSize = size; setTextColor(Color.WHITE); setTypeface(typeface, Typeface.BOLD)
            gravity = Gravity.CENTER_VERTICAL; setPadding(dp(20), dp(8), dp(14), dp(8)); isFocusable = false
            background = focusBackground(card); layoutParams = AbsListView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, height)
        }
    }

    inner class ProgramAdapter(
        private val items: List<EpgEntry>,
        private val now: Long,
        private val hasCatchup: Boolean
    ) : BaseAdapter() {
        override fun getCount() = items.size
        override fun getItem(position: Int) = items[position]
        override fun getItemId(position: Int) = position.toLong()
        override fun getView(position: Int, old: View?, parent: ViewGroup?): View {
            val program = items[position]
            val isNow = program.startEpoch <= now && now < program.endEpoch
            val isPast = program.endEpoch > 0 && program.endEpoch <= now
            return (old as? TextView ?: TextView(this@MainActivity)).apply {
                text = buildString {
                    append(if (isNow) "NOW  " else if (isPast && hasCatchup) "↶  " else "")
                    append("${time(program.startEpoch)}–${time(program.endEpoch)}   ${program.title}")
                    if (program.description.isNotBlank()) append("\n${program.description}")
                }
                textSize = 17f
                maxLines = 3
                setTextColor(Color.WHITE)
                setTypeface(typeface, if (isNow) Typeface.BOLD else Typeface.NORMAL)
                gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(22), dp(10), dp(18), dp(10))
                background = roundedDrawable(if (isNow) Color.rgb(55, 24, 28) else card, 0)
                layoutParams = AbsListView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(82))
            }
        }
    }

    inner class MediaAdapter(private val items: List<MediaEntry>) : BaseAdapter() {
        override fun getCount() = items.size
        override fun getItem(position: Int) = items[position]
        override fun getItemId(position: Int) = items[position].id.toLong()
        override fun getView(position: Int, old: View?, parent: ViewGroup?): View {
            val item = items[position]
            val isLive = item.kind == MediaKind.LIVE
            val root = old as? LinearLayout ?: LinearLayout(this@MainActivity).apply {
                setPadding(dp(12), dp(10), dp(12), dp(10))
                background = roundedDrawable(card, 0)
                isFocusable = false
            }
            root.removeAllViews()
            root.orientation = if (isLive) LinearLayout.HORIZONTAL else LinearLayout.VERTICAL
            root.gravity = Gravity.CENTER_VERTICAL
            val artwork = ImageView(this@MainActivity).apply {
                scaleType = if (isLive) ImageView.ScaleType.FIT_CENTER else ImageView.ScaleType.CENTER_CROP
                setImageResource(com.shqiptv.app.R.drawable.app_icon)
            }
            val label = TextView(this@MainActivity).apply {
                text = item.name
                textSize = if (isLive) 17f else 16f
                maxLines = if (isLive) 2 else 3
                setTextColor(Color.WHITE)
                setTypeface(typeface, Typeface.BOLD)
                gravity = if (isLive) Gravity.CENTER_VERTICAL else Gravity.CENTER
            }
            if (isLive) {
                root.addView(artwork, LinearLayout.LayoutParams(dp(70), dp(70)).apply { marginEnd = dp(14) })
                root.addView(label, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f))
                root.layoutParams = AbsListView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(104))
            } else {
                root.addView(artwork, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(122)))
                root.addView(label, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(54)))
                root.layoutParams = AbsListView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(196))
            }
            loadImage(item.icon, artwork)
            return root
        }
    }
}
