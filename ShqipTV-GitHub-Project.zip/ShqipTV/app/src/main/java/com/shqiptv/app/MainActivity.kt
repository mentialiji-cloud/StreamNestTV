package com.shqiptv.app

import android.app.Activity
import android.app.AlertDialog
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.StateListDrawable
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.*
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import java.net.HttpURLConnection
import java.net.URL
import kotlin.concurrent.thread

data class Channel(val name: String, val url: String, val group: String)

class MainActivity : Activity() {
    private val background = Color.rgb(8, 9, 13)
    private val panel = Color.rgb(22, 24, 31)
    private val card = Color.rgb(31, 34, 43)
    private val accent = Color.rgb(228, 30, 38)

    private var allChannels = listOf<Channel>()
    private var visibleChannels = listOf<Channel>()
    private var playingChannels = listOf<Channel>()
    private var playingIndex = 0
    private var player: ExoPlayer? = null
    private var playerView: PlayerView? = null
    private var playerOpen = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        val savedUrl = getPreferences(MODE_PRIVATE).getString("playlist_url", null)
        if (savedUrl.isNullOrBlank()) loadBundledPlaylist() else loadPlaylist(savedUrl)
    }

    private fun loadBundledPlaylist() {
        val text = assets.open("sample.m3u").bufferedReader().use { it.readText() }
        allChannels = parseM3u(text)
        showBrowser()
    }

    private fun loadPlaylist(url: String) {
        showLoading("Duke ngarkuar kanalet…")
        thread {
            try {
                val connection = URL(url).openConnection() as HttpURLConnection
                connection.connectTimeout = 15_000
                connection.readTimeout = 25_000
                connection.setRequestProperty("User-Agent", "ShqipTV/1.0")
                val text = connection.inputStream.bufferedReader().use { it.readText() }
                val parsed = parseM3u(text)
                runOnUiThread {
                    if (parsed.isEmpty()) {
                        toast("Nuk u gjet asnjë kanal")
                        loadBundledPlaylist()
                    } else {
                        allChannels = parsed
                        showBrowser()
                    }
                }
            } catch (error: Exception) {
                runOnUiThread {
                    toast("Gabim në listë: ${error.message}")
                    loadBundledPlaylist()
                }
            }
        }
    }

    private fun parseM3u(text: String): List<Channel> {
        val output = mutableListOf<Channel>()
        var pendingName = "Kanal"
        var pendingGroup = "Të tjera"
        text.lineSequence().forEach { raw ->
            val line = raw.trim()
            if (line.startsWith("#EXTINF", ignoreCase = true)) {
                val group = Regex("""group-title\s*=\s*"([^"]*)"""", RegexOption.IGNORE_CASE)
                    .find(line)?.groupValues?.getOrNull(1)
                pendingGroup = group?.ifBlank { "Të tjera" } ?: "Të tjera"
                pendingName = line.substringAfterLast(",").trim().ifBlank { "Kanal" }
            } else if (line.isNotBlank() && !line.startsWith("#")) {
                output += Channel(pendingName, line, pendingGroup)
            }
        }
        return output
    }

    private fun showLoading(message: String) {
        setContentView(TextView(this).apply {
            text = message
            textSize = 24f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setBackgroundColor(background)
        })
    }

    private fun showBrowser() {
        closePlayer()
        playerOpen = false
        window.clearFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN)
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_VISIBLE

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(background)
        }
        root.addView(createHeader())

        val content = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(dp(18), dp(10), dp(18), dp(18))
        }
        val categories = mutableListOf("Të gjitha kanalet")
        categories += allChannels.map { it.group }.distinct().sorted()

        val categoryList = ListView(this).apply {
            divider = ColorDrawable(Color.TRANSPARENT)
            dividerHeight = dp(6)
            selector = ColorDrawable(Color.TRANSPARENT)
            isVerticalScrollBarEnabled = false
            adapter = TextAdapter(categories, true)
        }

        visibleChannels = allChannels
        val grid = GridView(this).apply {
            numColumns = 3
            horizontalSpacing = dp(12)
            verticalSpacing = dp(12)
            stretchMode = GridView.STRETCH_COLUMN_WIDTH
            selector = ColorDrawable(Color.TRANSPARENT)
            isVerticalScrollBarEnabled = false
            clipToPadding = false
            setPadding(dp(16), 0, 0, dp(18))
            adapter = TextAdapter(visibleChannels.map { it.name }, false)
        }

        categoryList.setOnItemClickListener { _, _, position, _ ->
            visibleChannels = if (position == 0) allChannels
            else allChannels.filter { it.group == categories[position] }
            grid.adapter = TextAdapter(visibleChannels.map { it.name }, false)
            if (visibleChannels.isNotEmpty()) grid.post { grid.requestFocus() }
        }
        grid.setOnItemClickListener { _, _, position, _ ->
            playingChannels = visibleChannels
            playingIndex = position
            openChannel(playingChannels[position])
        }

        content.addView(categoryList, LinearLayout.LayoutParams(dp(245), ViewGroup.LayoutParams.MATCH_PARENT))
        content.addView(grid, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f))
        root.addView(content, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        setContentView(root)
        categoryList.post { categoryList.requestFocus() }
    }

    private fun createHeader(): View {
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(28), dp(15), dp(22), dp(15))
            setBackgroundColor(panel)
        }
        header.addView(TextView(this).apply {
            text = "SHQIP TV"
            textSize = 27f
            setTextColor(Color.WHITE)
            setTypeface(typeface, Typeface.BOLD)
        })
        header.addView(Space(this), LinearLayout.LayoutParams(0, 1, 1f))
        header.addView(createButton("Lista M3U") { showM3uDialog() })
        header.addView(createButton("Hyrje Xtream") { showXtreamDialog() }, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT
        ).apply { marginStart = dp(12) })
        return header
    }

    private fun createButton(label: String, action: () -> Unit) = Button(this).apply {
        text = label
        textSize = 15f
        setTextColor(Color.WHITE)
        isAllCaps = false
        isFocusable = true
        background = focusBackground(card)
        setOnClickListener { action() }
    }

    private fun showM3uDialog() {
        val input = EditText(this).apply {
            hint = "https://server/lista.m3u"
            setSingleLine(true)
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI
            setText(getPreferences(MODE_PRIVATE).getString("playlist_url", ""))
        }
        AlertDialog.Builder(this)
            .setTitle("Adresa e listës M3U")
            .setView(LinearLayout(this).apply { setPadding(dp(24), dp(10), dp(24), 0); addView(input) })
            .setPositiveButton("Ngarko") { _, _ ->
                input.text.toString().trim().takeIf { it.isNotBlank() }?.let {
                    getPreferences(MODE_PRIVATE).edit().putString("playlist_url", it).apply()
                    loadPlaylist(it)
                }
            }.setNegativeButton("Anulo", null).show()
    }

    private fun showXtreamDialog() {
        val form = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(24), dp(8), dp(24), 0) }
        val server = dialogInput("Adresa e serverit")
        val username = dialogInput("Përdoruesi")
        val password = dialogInput("Fjalëkalimi").apply {
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        }
        form.addView(server); form.addView(username); form.addView(password)
        AlertDialog.Builder(this).setTitle("Hyrje Xtream Codes").setView(form)
            .setPositiveButton("Hyr") { _, _ ->
                val base = server.text.toString().trim().trimEnd('/')
                val user = username.text.toString().trim()
                val pass = password.text.toString().trim()
                if (base.isNotBlank() && user.isNotBlank() && pass.isNotBlank()) {
                    val playlist = "$base/get.php?username=$user&password=$pass&type=m3u_plus&output=ts"
                    getPreferences(MODE_PRIVATE).edit().putString("playlist_url", playlist).apply()
                    loadPlaylist(playlist)
                }
            }.setNegativeButton("Anulo", null).show()
    }

    private fun dialogInput(hintText: String) = EditText(this).apply {
        hint = hintText
        setSingleLine(true)
        inputType = InputType.TYPE_CLASS_TEXT
    }

    private fun openChannel(channel: Channel) {
        playerOpen = true
        window.addFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN)
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_FULLSCREEN or
            View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
        player = ExoPlayer.Builder(this).build()
        playerView = PlayerView(this).apply {
            setBackgroundColor(Color.BLACK)
            useController = true
            controllerAutoShow = false
            player = this@MainActivity.player
        }
        setContentView(playerView)
        player?.apply { setMediaItem(MediaItem.fromUri(channel.url)); prepare(); playWhenReady = true }
        playerView?.showController()
    }

    private fun changeChannel(direction: Int) {
        if (playingChannels.isEmpty()) return
        playingIndex = (playingIndex + direction + playingChannels.size) % playingChannels.size
        val channel = playingChannels[playingIndex]
        player?.apply {
            stop(); clearMediaItems(); setMediaItem(MediaItem.fromUri(channel.url)); prepare(); playWhenReady = true
        }
        toast(channel.name)
    }

    override fun dispatchKeyEvent(event: KeyEvent): Boolean {
        if (playerOpen && event.action == KeyEvent.ACTION_DOWN) {
            when (event.keyCode) {
                KeyEvent.KEYCODE_DPAD_UP, KeyEvent.KEYCODE_CHANNEL_UP -> { changeChannel(-1); return true }
                KeyEvent.KEYCODE_DPAD_DOWN, KeyEvent.KEYCODE_CHANNEL_DOWN -> { changeChannel(1); return true }
                KeyEvent.KEYCODE_DPAD_CENTER, KeyEvent.KEYCODE_ENTER -> { playerView?.showController(); return true }
                KeyEvent.KEYCODE_BACK -> { showBrowser(); return true }
            }
        }
        return super.dispatchKeyEvent(event)
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() { if (playerOpen) showBrowser() else super.onBackPressed() }

    private fun closePlayer() {
        playerView?.player = null
        player?.release()
        player = null
        playerView = null
    }

    override fun onDestroy() { closePlayer(); super.onDestroy() }

    private fun focusBackground(normalColor: Int) = StateListDrawable().apply {
        addState(intArrayOf(android.R.attr.state_focused), ColorDrawable(accent))
        addState(intArrayOf(android.R.attr.state_pressed), ColorDrawable(accent))
        addState(intArrayOf(), ColorDrawable(normalColor))
    }

    private fun toast(message: String) = Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()

    inner class TextAdapter(private val items: List<String>, private val category: Boolean) : BaseAdapter() {
        override fun getCount() = items.size
        override fun getItem(position: Int) = items[position]
        override fun getItemId(position: Int) = position.toLong()
        override fun getView(position: Int, oldView: View?, parent: ViewGroup?): View {
            return (oldView as? TextView ?: TextView(this@MainActivity)).apply {
                text = items[position]
                textSize = 17f
                maxLines = 2
                setTextColor(Color.WHITE)
                setTypeface(typeface, if (category) Typeface.NORMAL else Typeface.BOLD)
                gravity = if (category) Gravity.CENTER_VERTICAL else Gravity.CENTER
                setPadding(dp(16), dp(8), dp(16), dp(8))
                isFocusable = false
                background = focusBackground(if (category) panel else card)
                layoutParams = AbsListView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(if (category) 58 else 108))
            }
        }
    }
}
