package com.shqiptv.app

import android.app.Activity
import android.app.AlertDialog
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.StateListDrawable
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.*
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.ConcurrentHashMap
import kotlin.concurrent.thread

class MainActivity : Activity() {
    private val bg = Color.rgb(7, 8, 12)
    private val panel = Color.rgb(20, 22, 29)
    private val card = Color.rgb(31, 34, 43)
    private val accent = Color.rgb(225, 28, 36)
    private val muted = Color.rgb(175, 180, 190)

    private val prefs by lazy { getSharedPreferences("shqip_tv", MODE_PRIVATE) }
    private var client: XtreamClient? = null
    private var m3uChannels = listOf<MediaEntry>()
    private val catalogCache = ConcurrentHashMap<MediaKind, List<MediaEntry>>()
    private val categoryCache = ConcurrentHashMap<MediaKind, List<Category>>()
    private val epgCache = ConcurrentHashMap<Int, List<EpgEntry>>()

    private var player: ExoPlayer? = null
    private var playerView: PlayerView? = null
    private var playerOpen = false
    private var playingItems = listOf<MediaEntry>()
    private var playingIndex = 0
    private var atHome = true

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        enterFullscreen()
        restoreAccount()
        val savedM3u = prefs.getString("m3u_url", "").orEmpty()
        if (client == null && savedM3u.isNotBlank()) loadM3u(savedM3u) else showHome()
    }

    private fun restoreAccount() {
        val server = prefs.getString("server", "").orEmpty()
        val username = prefs.getString("username", "").orEmpty()
        val password = prefs.getString("password", "").orEmpty()
        if (server.isNotBlank() && username.isNotBlank() && password.isNotBlank()) {
            client = XtreamClient(XtreamCredentials(server, username, password))
        }
    }

    private fun showHome() {
        atHome = true
        playerOpen = false
        closePlayer()
        enterFullscreen()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(bg)
            setPadding(dp(34), dp(24), dp(34), dp(28))
        }
        root.addView(header("SHQIP TV", false))
        root.addView(TextView(this).apply {
            text = if (client != null) "Mirë se vini • Xtream Codes connected" else "Shto listën tënde për të filluar"
            textSize = 18f
            setTextColor(muted)
            setPadding(0, dp(24), 0, dp(18))
        })
        val labels = listOf("●  LIVE TV", "▦  EPG GUIDE", "▶  MOVIES", "▣  SERIES", "★  FAVORITES", "⚙  ADD / SETTINGS")
        val grid = GridLayout(this).apply {
            columnCount = 3
            rowCount = 2
            useDefaultMargins = true
            alignmentMode = GridLayout.ALIGN_BOUNDS
        }
        labels.forEachIndexed { position, label ->
            val tile = TextView(this).apply {
                text = label
                textSize = 23f
                setTextColor(Color.WHITE)
                setTypeface(typeface, Typeface.BOLD)
                gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(26), dp(12), dp(18), dp(12))
                isFocusable = true
                isFocusableInTouchMode = true
                background = focusBackground(card)
                setOnClickListener {
                    when (position) {
                        0 -> openSection(MediaKind.LIVE, false)
                        1 -> openSection(MediaKind.LIVE, true)
                        2 -> openSection(MediaKind.MOVIE, false)
                        3 -> openSection(MediaKind.SERIES, false)
                        4 -> showFavorites()
                        5 -> showSourceDialog()
                    }
                }
                setOnFocusChangeListener { view, focused ->
                    view.animate().scaleX(if (focused) 1.035f else 1f).scaleY(if (focused) 1.035f else 1f).setDuration(100).start()
                }
            }
            grid.addView(tile, GridLayout.LayoutParams().apply {
                width = 0
                height = dp(150)
                columnSpec = GridLayout.spec(position % 3, 1f)
                rowSpec = GridLayout.spec(position / 3, 1f)
                setMargins(dp(9), dp(9), dp(9), dp(9))
            })
        }
        root.addView(grid, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        setContentView(root)
        grid.post { grid.getChildAt(0)?.requestFocus() }
    }

    private fun openSection(kind: MediaKind, epgMode: Boolean) {
        if (client == null) {
            if (kind == MediaKind.LIVE && m3uChannels.isNotEmpty()) {
                val m3uCategories = m3uChannels.map { it.categoryId }.distinct().map { Category(it, it) }
                showCatalog(kind, epgMode, m3uChannels, m3uCategories)
            }
            else showSourceDialog()
            return
        }
        catalogCache[kind]?.let { showCatalog(kind, epgMode, it, categoryCache[kind].orEmpty()); return }
        showLoading("Loading ${titleFor(kind)}…")
        thread {
            try {
                val items = client!!.catalog(kind)
                val categories = client!!.categories(kind)
                catalogCache[kind] = items
                categoryCache[kind] = categories
                runOnUiThread { showCatalog(kind, epgMode, items, categories) }
            } catch (error: Exception) {
                runOnUiThread { toast("Could not load: ${error.message}"); showHome() }
            }
        }
    }

    private fun showCatalog(kind: MediaKind, epgMode: Boolean, allItems: List<MediaEntry>, categories: List<Category>) {
        atHome = false
        enterFullscreen()
        var visible = allItems
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(bg) }
        val top = header(if (epgMode) "EPG GUIDE" else titleFor(kind), true)
        top.addView(actionButton("Search") { showSearch(kind, epgMode, allItems, categories) })
        root.addView(top)

        val body = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(dp(18), dp(12), dp(18), dp(18)) }
        val categoryNames = mutableListOf("All")
        categoryNames += categories.map { it.name }
        val categoryList = ListView(this).apply {
            divider = ColorDrawable(Color.TRANSPARENT); dividerHeight = dp(6)
            selector = selectionOutline(); isVerticalScrollBarEnabled = false
            adapter = TileAdapter(categoryNames, dp(58), 16f)
        }
        val grid = GridView(this).apply {
            numColumns = if (kind == MediaKind.LIVE) 2 else 3
            horizontalSpacing = dp(12); verticalSpacing = dp(12)
            stretchMode = GridView.STRETCH_COLUMN_WIDTH
            selector = selectionOutline(); isVerticalScrollBarEnabled = false
            setPadding(dp(14), 0, dp(14), dp(16))
            adapter = MediaAdapter(visible)
        }
        val epgPanel = createEpgPanel()

        fun refresh(items: List<MediaEntry>) {
            visible = items
            grid.adapter = MediaAdapter(visible)
            if (visible.isNotEmpty()) grid.post { grid.requestFocus() }
        }
        categoryList.setOnItemClickListener { _, _, position, _ ->
            if (position == 0) refresh(allItems)
            else {
                val selectedId = categories[position - 1].id
                refresh(allItems.filter { it.categoryId == selectedId })
            }
        }
        grid.setOnItemClickListener { _, _, position, _ ->
            val selected = visible[position]
            when (selected.kind) {
                MediaKind.SERIES -> loadEpisodes(selected)
                else -> { playingItems = visible; playingIndex = position; openPlayer(selected) }
            }
        }
        grid.setOnItemLongClickListener { _, _, position, _ -> toggleFavorite(visible[position]); true }
        if (kind == MediaKind.LIVE) {
            grid.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
                override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                    if (position in visible.indices) updateEpgPanel(epgPanel, visible[position])
                }
                override fun onNothingSelected(parent: AdapterView<*>?) = Unit
            }
        }
        body.addView(categoryList, LinearLayout.LayoutParams(dp(220), ViewGroup.LayoutParams.MATCH_PARENT))
        body.addView(grid, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f))
        if (kind == MediaKind.LIVE) body.addView(epgPanel, LinearLayout.LayoutParams(dp(330), ViewGroup.LayoutParams.MATCH_PARENT))
        root.addView(body, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        setContentView(root)
        categoryList.post { categoryList.requestFocus() }
    }

    private fun createEpgPanel() = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(20), dp(18), dp(20), dp(18))
        setBackgroundColor(panel)
        addView(TextView(this@MainActivity).apply { tag = "epg_title"; text = "PROGRAM GUIDE"; textSize = 21f; setTextColor(Color.WHITE); setTypeface(typeface, Typeface.BOLD) })
        addView(TextView(this@MainActivity).apply { tag = "epg_body"; text = "Focus a channel to see now and next."; textSize = 16f; setTextColor(muted); setPadding(0, dp(18), 0, 0) })
    }

    private fun updateEpgPanel(panelView: LinearLayout, channel: MediaEntry) {
        val title = panelView.findViewWithTag<TextView>("epg_title")
        val body = panelView.findViewWithTag<TextView>("epg_body")
        title.text = channel.name
        val cached = epgCache[channel.id]
        if (cached != null) { body.text = formatEpg(cached); return }
        if (client == null || channel.directUrl.isNotBlank()) { body.text = "EPG is supplied through Xtream Codes."; return }
        body.text = "Loading guide…"
        thread {
            try {
                val entries = client!!.shortEpg(channel.id)
                epgCache[channel.id] = entries
                runOnUiThread { if (title.text == channel.name) body.text = formatEpg(entries) }
            } catch (_: Exception) { runOnUiThread { if (title.text == channel.name) body.text = "No guide information available." } }
        }
    }

    private fun formatEpg(entries: List<EpgEntry>): String {
        if (entries.isEmpty()) return "No guide information available."
        val now = System.currentTimeMillis() / 1000
        val ordered = entries.filter { it.endEpoch == 0L || it.endEpoch >= now }.take(4)
        if (ordered.isEmpty()) return "No current programs."
        return ordered.joinToString("\n\n") {
            val marker = if (it.startEpoch <= now && now < it.endEpoch) "NOW" else "NEXT"
            "$marker  ${time(it.startEpoch)}–${time(it.endEpoch)}\n${it.title}\n${it.description}".trim()
        }
    }

    private fun loadEpisodes(series: MediaEntry) {
        val api = client ?: return
        showLoading("Loading episodes…")
        thread {
            try {
                val episodes = api.episodes(series.id)
                runOnUiThread { showEpisodeList(series.name, episodes) }
            } catch (error: Exception) { runOnUiThread { toast("Could not load episodes: ${error.message}"); showHome() } }
        }
    }

    private fun showEpisodeList(seriesName: String, episodes: List<MediaEntry>) {
        atHome = false
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(bg) }
        root.addView(header(seriesName, true))
        val list = GridView(this).apply {
            numColumns = 3; horizontalSpacing = dp(12); verticalSpacing = dp(12)
            setPadding(dp(28), dp(18), dp(28), dp(18)); selector = selectionOutline()
            adapter = MediaAdapter(episodes)
            setOnItemClickListener { _, _, position, _ -> playingItems = episodes; playingIndex = position; openPlayer(episodes[position]) }
        }
        root.addView(list, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        setContentView(root); list.post { list.requestFocus() }
    }

    private fun showFavorites() {
        val favorites = prefs.getStringSet("favorites", emptySet()).orEmpty()
        val all = catalogCache.values.flatten() + m3uChannels
        val items = all.distinctBy { "${it.kind}:${it.id}:${it.directUrl}" }.filter { favoriteKey(it) in favorites }
        if (items.isEmpty()) { toast("Hold OK on any item to add a favorite"); return }
        showCatalog(MediaKind.LIVE, false, items, emptyList())
    }

    private fun toggleFavorite(item: MediaEntry) {
        val set = prefs.getStringSet("favorites", emptySet()).orEmpty().toMutableSet()
        val key = favoriteKey(item)
        val added = if (key in set) { set.remove(key); false } else { set.add(key); true }
        prefs.edit().putStringSet("favorites", set).apply()
        toast(if (added) "Added to favorites" else "Removed from favorites")
    }

    private fun favoriteKey(item: MediaEntry) = "${item.kind}:${item.id}:${item.directUrl}"

    private fun showSearch(kind: MediaKind, epgMode: Boolean, items: List<MediaEntry>, categories: List<Category>) {
        val field = input("Search", "")
        AlertDialog.Builder(this).setTitle("Search ${titleFor(kind)}").setView(field)
            .setPositiveButton("Search") { _, _ ->
                val query = field.text.toString().trim()
                showCatalog(kind, epgMode, items.filter { it.name.contains(query, true) }, categories)
            }.setNegativeButton("Cancel", null).show()
    }

    private fun showSourceDialog() {
        AlertDialog.Builder(this).setTitle("Add TV service")
            .setItems(arrayOf("Xtream Codes", "M3U playlist", "Cancel")) { dialog, which ->
                when (which) { 0 -> showXtreamLogin(); 1 -> showM3uLogin(); else -> dialog.dismiss() }
            }.show()
    }

    private fun showXtreamLogin() {
        val form = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(24), dp(8), dp(24), 0) }
        val server = input("Server URL", prefs.getString("server", "").orEmpty())
        val username = input("Username", prefs.getString("username", "").orEmpty())
        val password = input("Password", prefs.getString("password", "").orEmpty()).apply {
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        }
        form.addView(server); form.addView(username); form.addView(password)
        AlertDialog.Builder(this).setTitle("Xtream Codes").setView(form)
            .setPositiveButton("Connect") { _, _ ->
                connectXtream(XtreamCredentials(server.text.toString(), username.text.toString(), password.text.toString()))
            }.setNegativeButton("Cancel", null).show()
    }

    private fun connectXtream(credentials: XtreamCredentials) {
        showLoading("Connecting…")
        thread {
            try {
                val newClient = XtreamClient(credentials)
                if (!newClient.authenticate()) error("Login was rejected")
                client = newClient; catalogCache.clear(); categoryCache.clear(); epgCache.clear()
                prefs.edit().putString("server", credentials.server.trim().trimEnd('/'))
                    .putString("username", credentials.username.trim()).putString("password", credentials.password).apply()
                runOnUiThread { toast("Connected"); showHome() }
            } catch (error: Exception) { runOnUiThread { toast("Login failed: ${error.message}"); showHome() } }
        }
    }

    private fun showM3uLogin() {
        val field = input("M3U playlist URL", prefs.getString("m3u_url", "").orEmpty())
        AlertDialog.Builder(this).setTitle("M3U playlist").setView(field)
            .setPositiveButton("Load") { _, _ -> loadM3u(field.text.toString().trim()) }
            .setNegativeButton("Cancel", null).show()
    }

    private fun loadM3u(address: String) {
        if (address.isBlank()) return
        showLoading("Loading M3U…")
        thread {
            try {
                val connection = URL(address).openConnection() as HttpURLConnection
                connection.connectTimeout = 12_000; connection.readTimeout = 25_000
                connection.setRequestProperty("User-Agent", "ShqipTV/2.0")
                val text = connection.inputStream.bufferedReader().use { it.readText() }
                connection.disconnect()
                m3uChannels = parseM3u(text)
                prefs.edit().putString("m3u_url", address).apply()
                runOnUiThread { toast("${m3uChannels.size} channels loaded"); showHome() }
            } catch (error: Exception) { runOnUiThread { toast("M3U error: ${error.message}"); showHome() } }
        }
    }

    private fun parseM3u(text: String): List<MediaEntry> {
        val result = mutableListOf<MediaEntry>(); var name = "Channel"; var group = "Other"; var id = 1
        text.lineSequence().forEach { raw ->
            val line = raw.trim()
            if (line.startsWith("#EXTINF", true)) {
                name = line.substringAfterLast(',').trim().ifBlank { "Channel" }
                group = Regex("""group-title\s*=\s*"([^"]*)"""", RegexOption.IGNORE_CASE)
                    .find(line)?.groupValues?.getOrNull(1)?.ifBlank { "Other" } ?: "Other"
            } else if (line.isNotBlank() && !line.startsWith("#")) {
                result += MediaEntry(id++, name, group, MediaKind.LIVE, directUrl = line)
            }
        }
        return result
    }

    private fun openPlayer(item: MediaEntry) {
        val url = if (item.directUrl.isNotBlank()) item.directUrl else client?.streamUrl(item).orEmpty()
        if (url.isBlank()) { toast("Stream URL unavailable"); return }
        playerOpen = true; enterFullscreen()
        player = ExoPlayer.Builder(this).build()
        playerView = PlayerView(this).apply {
            setBackgroundColor(Color.BLACK); useController = true; controllerAutoShow = false
            player = this@MainActivity.player
        }
        setContentView(playerView)
        player?.apply { setMediaItem(MediaItem.fromUri(url)); prepare(); playWhenReady = true }
        playerView?.showController()
    }

    private fun changeChannel(delta: Int) {
        if (playingItems.isEmpty()) return
        playingIndex = (playingIndex + delta + playingItems.size) % playingItems.size
        val next = playingItems[playingIndex]
        if (next.kind == MediaKind.SERIES) return
        val url = if (next.directUrl.isNotBlank()) next.directUrl else client?.streamUrl(next).orEmpty()
        player?.apply { stop(); clearMediaItems(); setMediaItem(MediaItem.fromUri(url)); prepare(); playWhenReady = true }
        toast(next.name)
    }

    override fun dispatchKeyEvent(event: KeyEvent): Boolean {
        if (playerOpen && event.action == KeyEvent.ACTION_DOWN) {
            when (event.keyCode) {
                KeyEvent.KEYCODE_DPAD_UP, KeyEvent.KEYCODE_DPAD_LEFT,
                KeyEvent.KEYCODE_CHANNEL_UP -> { changeChannel(-1); return true }
                KeyEvent.KEYCODE_DPAD_DOWN, KeyEvent.KEYCODE_DPAD_RIGHT,
                KeyEvent.KEYCODE_CHANNEL_DOWN -> { changeChannel(1); return true }
                KeyEvent.KEYCODE_DPAD_CENTER, KeyEvent.KEYCODE_ENTER -> { playerView?.showController(); return true }
                KeyEvent.KEYCODE_BACK -> { showHome(); return true }
            }
        }
        return super.dispatchKeyEvent(event)
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() { if (atHome) super.onBackPressed() else showHome() }

    private fun header(title: String, back: Boolean) = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
        setPadding(dp(22), dp(14), dp(22), dp(14)); setBackgroundColor(panel)
        if (back) addView(actionButton("← Home") { showHome() })
        addView(TextView(this@MainActivity).apply {
            text = title; textSize = 27f; setTextColor(Color.WHITE); setTypeface(typeface, Typeface.BOLD)
            setPadding(if (back) dp(20) else 0, 0, 0, 0)
        })
        addView(Space(this@MainActivity), LinearLayout.LayoutParams(0, 1, 1f))
        addView(TextView(this@MainActivity).apply { text = "AL"; textSize = 18f; setTextColor(accent); setTypeface(typeface, Typeface.BOLD) })
    }

    private fun actionButton(label: String, action: () -> Unit) = Button(this).apply {
        text = label; textSize = 15f; setTextColor(Color.WHITE); isAllCaps = false
        isFocusable = true; background = focusBackground(card); setOnClickListener { action() }
    }

    private fun input(hintText: String, value: String) = EditText(this).apply {
        hint = hintText; setText(value); setSingleLine(true); inputType = InputType.TYPE_CLASS_TEXT
    }

    private fun showLoading(textValue: String) {
        setContentView(TextView(this).apply {
            text = textValue; textSize = 25f; setTextColor(Color.WHITE); gravity = Gravity.CENTER; setBackgroundColor(bg)
        })
    }

    private fun titleFor(kind: MediaKind) = when (kind) {
        MediaKind.LIVE -> "LIVE TV"; MediaKind.MOVIE -> "MOVIES"; MediaKind.SERIES -> "SERIES"; MediaKind.EPISODE -> "EPISODES"
    }

    private fun time(epoch: Long): String = if (epoch <= 0) "--:--" else SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date(epoch * 1000))

    private fun enterFullscreen() {
        window.addFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN)
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
    }

    private fun leaveFullscreen() {
        playerOpen = false; window.clearFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN)
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_VISIBLE
    }

    private fun closePlayer() { playerView?.player = null; player?.release(); player = null; playerView = null }
    override fun onDestroy() { closePlayer(); super.onDestroy() }
    private fun toast(message: String) = Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()

    private fun focusBackground(normal: Int) = StateListDrawable().apply {
        addState(intArrayOf(android.R.attr.state_focused), ColorDrawable(accent))
        addState(intArrayOf(android.R.attr.state_pressed), ColorDrawable(accent))
        addState(intArrayOf(), ColorDrawable(normal))
    }

    private fun selectionOutline() = GradientDrawable().apply {
        setColor(Color.TRANSPARENT)
        setStroke(dp(5), accent)
        cornerRadius = dp(8).toFloat()
    }

    inner class TileAdapter(private val labels: List<String>, private val height: Int, private val size: Float) : BaseAdapter() {
        override fun getCount() = labels.size
        override fun getItem(position: Int) = labels[position]
        override fun getItemId(position: Int) = position.toLong()
        override fun getView(position: Int, old: View?, parent: ViewGroup?) = (old as? TextView ?: TextView(this@MainActivity)).apply {
            text = labels[position]; textSize = size; setTextColor(Color.WHITE); setTypeface(typeface, Typeface.BOLD)
            gravity = Gravity.CENTER_VERTICAL; setPadding(dp(20), dp(8), dp(14), dp(8)); isFocusable = false
            background = focusBackground(card); layoutParams = AbsListView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, height)
        }
    }

    inner class MediaAdapter(private val items: List<MediaEntry>) : BaseAdapter() {
        override fun getCount() = items.size
        override fun getItem(position: Int) = items[position]
        override fun getItemId(position: Int) = items[position].id.toLong()
        override fun getView(position: Int, old: View?, parent: ViewGroup?) = (old as? TextView ?: TextView(this@MainActivity)).apply {
            text = items[position].name; textSize = 17f; maxLines = 3; setTextColor(Color.WHITE)
            setTypeface(typeface, Typeface.BOLD); gravity = Gravity.CENTER; setPadding(dp(12), dp(10), dp(12), dp(10)); isFocusable = false
            background = focusBackground(card); layoutParams = AbsListView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(106))
        }
    }
}
