package com.shqiptv.app

import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

class XtreamClient(private val credentials: XtreamCredentials) {
    private val base = credentials.server.trim().trimEnd('/')
    private val user = encode(credentials.username)
    private val pass = encode(credentials.password)

    fun authenticate(): Boolean {
        val root = JSONObject(get(apiUrl()))
        return root.optJSONObject("user_info")?.optInt("auth", 0) == 1
    }

    fun categories(kind: MediaKind): List<Category> {
        val action = when (kind) {
            MediaKind.LIVE -> "get_live_categories"
            MediaKind.MOVIE -> "get_vod_categories"
            MediaKind.SERIES -> "get_series_categories"
            MediaKind.EPISODE -> return emptyList()
        }
        val array = JSONArray(get(apiUrl(action)))
        return buildList {
            for (index in 0 until array.length()) {
                val item = array.optJSONObject(index) ?: continue
                add(Category(item.optString("category_id"), item.optString("category_name", "Other")))
            }
        }
    }

    fun catalog(kind: MediaKind): List<MediaEntry> {
        val action = when (kind) {
            MediaKind.LIVE -> "get_live_streams"
            MediaKind.MOVIE -> "get_vod_streams"
            MediaKind.SERIES -> "get_series"
            MediaKind.EPISODE -> return emptyList()
        }
        val array = JSONArray(get(apiUrl(action)))
        return buildList {
            for (index in 0 until array.length()) {
                val item = array.optJSONObject(index) ?: continue
                val id = if (kind == MediaKind.SERIES) item.optInt("series_id") else item.optInt("stream_id")
                if (id == 0) continue
                add(
                    MediaEntry(
                        id = id,
                        name = item.optString("name", "Untitled"),
                        categoryId = item.optString("category_id"),
                        kind = kind,
                        icon = item.optString(if (kind == MediaKind.SERIES) "cover" else "stream_icon"),
                        extension = item.optString("container_extension", if (kind == MediaKind.LIVE) "ts" else "mp4")
                    )
                )
            }
        }
    }

    fun shortEpg(streamId: Int): List<EpgEntry> {
        val root = JSONObject(get(apiUrl("get_short_epg", "&stream_id=$streamId&limit=8")))
        val array = root.optJSONArray("epg_listings") ?: JSONArray()
        return buildList {
            for (index in 0 until array.length()) {
                val item = array.optJSONObject(index) ?: continue
                add(
                    EpgEntry(
                        title = decodeText(item.optString("title")),
                        description = decodeText(item.optString("description")),
                        startEpoch = item.optLong("start_timestamp", 0),
                        endEpoch = item.optLong("stop_timestamp", 0)
                    )
                )
            }
        }
    }

    fun episodes(seriesId: Int): List<MediaEntry> {
        val root = JSONObject(get(apiUrl("get_series_info", "&series_id=$seriesId")))
        val seasons = root.optJSONObject("episodes") ?: return emptyList()
        val result = mutableListOf<MediaEntry>()
        val keys = seasons.keys()
        while (keys.hasNext()) {
            val season = keys.next()
            val array = seasons.optJSONArray(season) ?: continue
            for (index in 0 until array.length()) {
                val item = array.optJSONObject(index) ?: continue
                val id = item.optInt("id")
                if (id == 0) continue
                result += MediaEntry(
                    id = id,
                    name = "S$season • ${item.optString("title", "Episode ${index + 1}")}",
                    categoryId = season,
                    kind = MediaKind.EPISODE,
                    extension = item.optString("container_extension", "mp4")
                )
            }
        }
        return result
    }

    fun streamUrl(item: MediaEntry): String {
        if (item.directUrl.isNotBlank()) return item.directUrl
        val section = when (item.kind) {
            MediaKind.LIVE -> "live"
            MediaKind.MOVIE -> "movie"
            MediaKind.EPISODE -> "series"
            MediaKind.SERIES -> error("Select an episode first")
        }
        return "$base/$section/$user/$pass/${item.id}.${item.extension}"
    }

    private fun apiUrl(action: String? = null, extra: String = ""): String {
        val actionPart = action?.let { "&action=$it" } ?: ""
        return "$base/player_api.php?username=$user&password=$pass$actionPart$extra"
    }

    private fun get(address: String): String {
        val connection = URL(address).openConnection() as HttpURLConnection
        connection.connectTimeout = 12_000
        connection.readTimeout = 25_000
        connection.setRequestProperty("User-Agent", "ShqipTV/2.0")
        connection.setRequestProperty("Accept", "application/json")
        return try {
            if (connection.responseCode !in 200..299) error("Server error ${connection.responseCode}")
            connection.inputStream.bufferedReader().use { it.readText() }
        } finally {
            connection.disconnect()
        }
    }

    private fun decodeText(value: String): String {
        if (value.isBlank()) return ""
        return try { String(Base64.decode(value, Base64.DEFAULT), Charsets.UTF_8) } catch (_: Exception) { value }
    }

    private fun encode(value: String): String = URLEncoder.encode(value, "UTF-8")
}
