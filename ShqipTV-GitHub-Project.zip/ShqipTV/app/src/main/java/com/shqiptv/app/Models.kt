package com.shqiptv.app

enum class MediaKind { LIVE, MOVIE, SERIES, EPISODE }

data class Category(val id: String, val name: String)

data class MediaEntry(
    val id: Int,
    val name: String,
    val categoryId: String,
    val kind: MediaKind,
    val icon: String = "",
    val extension: String = "ts",
    val directUrl: String = ""
)

data class EpgEntry(
    val title: String,
    val description: String,
    val startEpoch: Long,
    val endEpoch: Long
)

data class XtreamCredentials(val server: String, val username: String, val password: String)
