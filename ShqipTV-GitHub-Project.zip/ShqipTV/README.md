# Shqip TV

Android TV IPTV player with M3U and Xtream Codes support.

## Build on GitHub

Open **Actions**, choose **Build Shqip TV APK**, then select **Run workflow**.
Download **Shqip-TV-APK** from the completed run's Artifacts section.

Use only playlists and streams you are authorized to access.
