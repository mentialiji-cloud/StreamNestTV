# Shqip TV for Google TV

An original remote-first IPTV player for Google TV and Android TV devices.

## Core experience

- Google TV-only launcher entry and 16:9 ten-foot interface
- ONN remote D-pad, OK, Back, and Channel Up/Down support
- Xtream Codes and M3U playlist login
- Multiple saved playlists with quick switching
- Live TV groups, fast channel switching, and full-screen playback
- Now/next EPG information from supported Xtream providers
- Full program list and catch-up playback where the provider supports it
- Movies, series, seasons, and episodes
- Search, favorites, and recent history
- Multi-view for up to four live channels
- Parental PIN and automatic adult-group filtering
- Built-in or external player and FIT/FILL/ZOOM video scaling
- Channel logos and VOD artwork
- Albanian eagle launcher icon and TV banner

The app supplies no channels or media. Use only services and playlists you are authorized to access.

Fast native Android TV IPTV player branded Shqip TV.

Features:

- Xtream Codes login and M3U playlist support
- Live TV categories with focused-channel now/next EPG
- Movies, series, seasons and episode playback
- Search and favorites
- D-pad optimized lazy channel grids
- True immersive full-screen Media3 playback
- Up/down channel switching while watching live TV

## Build on GitHub

Open **Actions**, choose **Build Shqip TV APK**, then select **Run workflow**.
Download **Shqip-TV-APK** from the completed run's Artifacts section.

Use only playlists and streams you are authorized to access.
